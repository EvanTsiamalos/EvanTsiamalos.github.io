package model.tileCollection;
import model.tile.*;
import java.util.ArrayList;

/**
 * Class that describes any collection of tiles of the same type, used by the players and the board
 * @author tem2604
 *
 */

public class TileCollection {
	
	private ArrayList<Tile> tiles ;
	
	/**
	 * <b>Constructor</b>
	 * <b>Postcondition</b> Creates a new empty TileCollecion
	 */
	public TileCollection() {
		this.tiles = new ArrayList<Tile>();
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Postcondition</b> adds the tile to the collecion
	 * @param tile Tile to add in the collection
	 */
	public void addTile(Tile tile) {
		tiles.add(tile);
	}
	
	/**
	 * <b>Observer</b> 
	 * <b>Precondition:</b> i must not exceed the size of the collecion
	 * <b>Postcondition</b> Returns the tile in position i
	 * @param i i is less than the tiles.size()
	 * @return	the tile in position i
	 */
	public Tile getTile(int i) {
		return tiles.get(i);
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Precondition:</b> i must not exceed the size of the collection
	 * <b>Postcondition:</b> removes the Tile in position i
	 * @param i  i is less than the tiles.size()
	 */
	public void removeTile(int i) {
		tiles.remove(i);
	}
	
	public void removeTile(Tile tile) {
		this.tiles.remove(tile);
	}
	/**
	 * <b>Accessor</b>
	 * <b>Precondition:</b> Tile must exist in the collection
	 * <b>Postcondition:</b> Get the indecx of the tile in the collection
	 * @param tile the tile to get the index
	 * @return the index of the tile
	 */
	public int getTileIndex(Tile tile) {
		return this.tiles.indexOf(tile);
	}
	
	/**
	 * <b>Observer</b>
	 * <b>Postcondition:</b> checks if the collection is empty 
	 * @return true if collection is empty
	 */
	public boolean isEmpty() {
		return tiles.size() == 0;
	}
	
	/**
	 * <b>Observer</b>
	 * <b>Postcondition</b> Gets the size of the collection
	 * @return	the size of the collection
	 */
	public int size() {
		return tiles.size();
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition</b> Get the tiles of the collection
	 * @return the tiles of the collection
	 */
	public ArrayList<Tile> getTiles() {
		return this.tiles;
	}
	

	
}



