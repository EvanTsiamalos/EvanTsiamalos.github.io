package model.tile;


/**
 * Class that represents the finding Tiles
 * @author Public-IT
 *
 */
public abstract class FindingTile extends Tile {
	
	
	public abstract boolean equals(Object o2);
	
	public String toString() {
		return "Finding Tile";
	}
}
