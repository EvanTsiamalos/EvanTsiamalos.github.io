package model.tile;


/**
 * Class that describes the skeleton tiles
 * @author tem2604
 *
 */
public class SkeletonTile extends FindingTile{
	private int size;
	private int part;
	
	
	/**
	 * <b>Constructor</b> SkeletonTile
	 * <b>Precondition:</b> size and part are integers 0 or 1
	 * <b>Postcondition:</b> create Skeleton Tile of size and part
	 * @param size integer that describes Size of skeleton
	 * @param part integer that describes the part of the skeleton
	 */
	public SkeletonTile(int size, int part) {
		this.part = part;
		this.size = size;
	}
	
	/**
	 * <b>Transformer</b> Sets the skeletons size
	 * 
	 * <b>Postcondition:</b> Sets the size of the skeleton 
	 * @param s integer 0 or 1
	 */
	public void setSize(int s) {
		this.size = s;
		
	}
	
	/**
	 * <b>Accessor</b> Gets the size of the skeleton
	 * <b>Precondition:</b> skeleton must have a size
	 * <b>Postcondition:</b> Returns the size 0 or 1
	 * @return the size of the skeleton
	 */
	public int getSize() {
		return this.size;
	}
	
	/**
	 * <b>Transformer</b> Sets the skeletons part
	 * 
	 * <b>Postcondition:</b> Sets the part of the skeleton 
	 * @param p integer 0 or 1
	 */
	public void setPart(int p) {
		this.part = p;
	}
	
	/**
	 * <b>Accessor</b> Gets the part of the skeleton
	 * <b>Precondition:</b> skeleton must have a part
	 * <b>Postcondition:</b> Returns the part 0 or 1
	 * @return the part of the skeleton
	 */
	public int getaPart() {
		return this.part;
	}
	
	/**
	 * Override the equals method
	 */
	public boolean equals(Object o2) {
		if (o2 instanceof SkeletonTile) {
			SkeletonTile s = ((SkeletonTile) o2);
			return this.part == s.getaPart() && this.size == s.getSize();
		}
		return false;
	}
	
	/**
	 * Override the toString method
	 */
	public String toString() {
		return "Skeleton tile of size " + (this.size ==0 ? "SMALL" : "BIG") + " part " + (this.part==0 ? "TOP":"BOTTOM");
	}
}
