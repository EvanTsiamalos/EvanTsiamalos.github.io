package model.tile;


/**
 * Class that represents the tile of LandSlide rocks
 * @author Public-IT
 *
 */
public class RockTile extends Tile {
	
	public String toString() {
		return "Rock Tile";
	}
}
