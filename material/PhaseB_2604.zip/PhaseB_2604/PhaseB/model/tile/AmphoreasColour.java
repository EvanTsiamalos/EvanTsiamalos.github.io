package model.tile;


/**
 * Enumeration of the colours of the AmphoreasTiles
 * @author tem2604
 *
 */
public enum AmphoreasColour {
	BLUE,
	GREEN,
	BROWN,
	RED,
	YELLOW,
	PURPLE
}
