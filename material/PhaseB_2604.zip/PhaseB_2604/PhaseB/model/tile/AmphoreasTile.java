package model.tile;

/**
 * Class AmphoreasTile describes the tiles of Amphoras in the game.
 * @author tem2604
 * 
 *
 */
public class AmphoreasTile extends FindingTile {
	
	private  AmphoreasColour colour;
	
	/**
	 * Constructor
	 * 
	 * <b>Precondition:</b> The colour must be enumerated and not null
	 * <b>Postcondition:</b> Creates amphora tile of specified colour
	 * @param colour the colour of amphoreas
	 */
	public AmphoreasTile(AmphoreasColour colour) {
		this.colour = colour;
	}
	
	/**
	 * <b>Transformer</b> Sets the AmphoraTile 's colour
	 * 
	 * <b>Precondition:</b> The colour is enumarated and not null
	 * <b>Postcondition:</b> Sets the colour
	 * @param c the colour to set
	 */
	public void setColour(AmphoreasColour c) {
		this.colour = c;
	}
	
	/**
	 * <b>Accesor</b> Gets the AmphoraTile 's colour
	 * 
	 * <b>Precondition:</b> The Amphora must have a colour
	 * <b>Postcondition:</b> returns the colour
	 * 
	 * @return colour of the Amphora
	 */
	public AmphoreasColour getColour() {
		return this.colour;
	}
	
	
	
	public boolean equals(Object o2) {
		if (o2 instanceof AmphoreasTile) {
			return this.colour == ((AmphoreasTile) o2).getColour();
		}
		return false;
	}
	
	public String toString() {
		return "Amphoreas tile of colour " + this.colour;
	}
	
}
