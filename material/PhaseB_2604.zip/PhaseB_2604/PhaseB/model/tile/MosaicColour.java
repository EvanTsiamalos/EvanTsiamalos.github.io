package model.tile;


/**
 * Enumeration of the colours of mosaic tiles
 * @author tem2604
 *
 */
public enum MosaicColour {
	GREEN,
	RED,
	YELLOW
}


