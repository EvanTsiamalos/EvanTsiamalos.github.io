package model.tile;

/**
 * Class that describes the Mosaic Tiles
 * @author tem2604
 *
 */
public class MosaicTile extends FindingTile {
	private MosaicColour colour;
	
	/**
	 * <b>Constructor</b>
	 * 
	 * <b>Precondition:</b> colour must be enumerated and not null
	 * <b>Postcondition</b> creates mosaic of given colour
	 * @param colour the colour of the mosaic
	 */
	
	public MosaicTile(MosaicColour colour) {
		this.colour = colour;
	}
	
	
	/**
	 * <b>Transformer</b> Sets the mosaic 's colour
	 * 
	 * <b>Precondition:</b> The colour is enumarated and not null
	 * <b>Postcondition:</b> Sets the colour
	 * @param c the colour to set
	 */
	public void setColour(MosaicColour c) {
		this.colour = c;
	}
	
	/**
	 * <b>Accesor</b> Gets the mosaics 's colour
	 * 
	 * <b>Precondition:</b> The mosaic must have a colour
	 * <b>Postcondition:</b> returns the colour
	 * 
	 * @return colour of the mosaic
	 */
	public MosaicColour getColour() {
		return this.colour;
	}
	
	
	/**
	 * Override the equals method
	 */
	public boolean equals(Object o2) {
		if (o2 instanceof MosaicTile) {
			return this.colour == ((MosaicTile) o2).getColour();
		}
		return false;
	}
	
	/**
	 * Override the toString method
	 */
	public String toString() {
		return "Mosaic of colour " + colour;
	}
	
	
}
