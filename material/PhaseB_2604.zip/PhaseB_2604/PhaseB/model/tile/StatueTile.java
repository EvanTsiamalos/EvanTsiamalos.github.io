package model.tile;


/**
 * Class that represnts the statue tiles in the game
 * @author Public-IT
 *
 */
public class StatueTile extends FindingTile {
	private String type;
	
	
	/**
	 * <b>Constructor</b>
	 * 
	 * <b>Postcondition:</b> Creates a new statue of specified type, Sphinx or Karyatida
	 * @param type String "SPHINX" or "KRYATIDA" 
	 */
	public StatueTile(String type) {
		this.type = type;
	}
	
	/**
	 * <b>Observer:</b> gets the type of the statue
	 * <b>Precondition</b> Type is not null
	 * <b>Postcondition</b> Gets the type of statue
	 * @return String type, the type of statue
	 */
	public String getType() {
		return this.type;
	}
	
	/**
	 * <b>Transformer</b> Sets the type of the statue
	 * <b>Precondition</b> Not null arguments
	 * <b>Postcondition</b> type is changed
	 * @param type String "SPHINX" or "KARYATIDA"
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	public boolean equals(Object o2) {
		if (o2 instanceof StatueTile) {
			StatueTile s = (StatueTile) o2;
			return this.type == s.getType();
		}
		return false;
	}
	
	public String toString () {
		return "Statue tile: " + type;
	}
	
}
