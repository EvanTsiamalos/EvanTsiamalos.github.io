package model.tile;


/**
 * Class that represents the tiles of the game
 * @author Public-IT
 *
 */
public abstract class Tile {
	
	
	
	public abstract String toString();
	
	
}
