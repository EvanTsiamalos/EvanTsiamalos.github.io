package model.board;
import java.util.ArrayList;

import model.tile.*;
import model.tileCollection.*;
import model.player.*;
import model.bag.*;
import model.card.*;

/**
 * Class that describes the Board of the game
 * @author tem2604
 *
 */
public class Board {
	private TileCollection  amphoreasArea;
	private TileCollection mosaicArea;
	private TileCollection  rockArea;				//Tilecollections that represent the five areas of tiles on the board
	private TileCollection  skeletonArea;			
	private TileCollection  statueArea;			
	
	private static int turn;	// Static int that represents the turn. It counts throughout the whole game and it helps in 
									//getting the next player to play
	
	private int playingPosition;	//Position on the board playing 0 1 2 3
									// 0 is the position looking at the board directly and continues going counter clock-wise 

	private int areaPlayed;		// the area that the player has picked a tile from 0 1 2 3
								//0 is the skeleton area and moving counter clock-wise

	
	private boolean characterIsPlayed; // declares if a character card is played by a player
	private int numberOfTilesPicked;		// total number of tiles picked by a player every time they play
	private static final int RockAreaCapacity = 16;


	
	/**
	 * <b>Constructor</b> Initiallizes some of the variants
	 * <b>Postcondition:</b> Creates the board
	 */
	
	public Board() {
		this.amphoreasArea = new TileCollection();
		this.mosaicArea = new TileCollection();
		this.skeletonArea = new TileCollection();
		this.statueArea = new TileCollection();
		this.rockArea = new TileCollection();
		
		this.turn = 0;
	
		this.numberOfTilesPicked = 0;
		this.characterIsPlayed = false;
	}
	
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the collection of skeletons on the board
	 * @return the TileCollection of skeletons
	 */
	public TileCollection getSkeletonArea() {
		return this.skeletonArea;
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the collection of amphoras on the board
	 * @return the TileCollection of amphoras
	 */
	public TileCollection getAmphoreasArea() {return this.amphoreasArea;}
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the collection of mosaics on the board
	 * @return the TileCollection of mosaics
	 */
	public TileCollection getMosaicArea() {return this.mosaicArea;}
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the collection of statues on the board
	 * @return the TileCollection of statues
	 */
	public TileCollection getStatueArea() {return this.statueArea;}
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the collection of rocks on the board
	 * @return the TileCollection of rocks
	 */
	public TileCollection getRockArea() {return this.rockArea;}
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> area is not null and has tiles of type SkeletonTile
	 * <b>Postcondition:</b> Sets the skeletonTile area
	 * @param area the new Tilecollection of skeletonTiles
	 */
	public void setSkeletonArea(TileCollection area) {this.skeletonArea = area;}
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> area is not null and has tiles of type AmphoreasTile
	 * <b>Postcondition:</b> Sets the amphoreasTile area
	 * @param area the new Tilecollection of AmphoreasTiles
	 */
	public void setAmphoreasArea(TileCollection area) {this.amphoreasArea = area;}
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> area is not null and has tiles of type MosaicTile
	 * <b>Postcondition:</b> Sets the mosaicTile area
	 * @param area the new Tilecollection of mosaicTiles
	 */
	public void setMosaicArea(TileCollection area) {this.mosaicArea = area;}
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> area is not null and has tiles of type StatueTile
	 * <b>Postcondition:</b> Sets the statueTile area
	 * @param area the new Tilecollection of statueTiles
	 */
	public void setStatueArea(TileCollection area) {this.statueArea = area;}
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> area is not null and has tiles of type rockTile
	 * <b>Postcondition:</b> Sets the rockTile area
	 * @param area the new Tilecollection of rockTiles
	 */
	public void setRockArea(TileCollection area) {this.rockArea = area;}


	
	/**
	 * <b>Accessor</b>
	 * <b>Precondition:</b> playingPosition must be initiallized
	 * <b>Postcondition</b> Gets the position of the board that is to play 0,1,2 or 3
	 * @return 0 or 1 or 2 or 3 the position that is playing
	 */
	public int getPlayingPosition() {
		return this.playingPosition;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> Parameter i is 0,1,2 or 3 
	 * <b>Postcondition:</b> Sets the playingPosition to i
	 * @param i  i = 0,1,2 or 3 
	 */
	public void setPlayingPosition(int i) {
		this.playingPosition = i;
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Precondition:</b> the areaPlayed must be initiallized
	 * <b>Postcondition:</b> gets the TileArea of the board that the player has chosen to pick tiles from
	 * @return 0,1,2 or 3
	 */
	public int getAreaPlayed() {
		return this.areaPlayed; //0 , 1, 2, 3 to know if we use the characters or for simple choice
	}

	/**
	 * <b>transformer</b>
	 * <b>Precondition</b> the area to set is 0,1,2 or 3
	 * <b>Postcondition:</b> Sets the areaPlayed
	 * @param area the area played 0,1,2 or 3
	 */
	public void setAreaPlayed(int area) {
		this.areaPlayed = area;
	}
	
	
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the number of tiles that have been picked by the board 
	 * @return the number of tiles picked
	 */
	public int getNumberOfTilesPicked() {
		return this.numberOfTilesPicked;
	}
	
	/**
	 * <b>Transformer</b>
	 * 
	 * <b>Postcondition</b> Sets the number of tiles that a player has picked
	 * @param i i >= 0
	 */
	public void setNumberOfTilesPicked(int i) {}
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition</b> Gets the turn. the turn is static int that keeps counting throughout the game
	 * @return the turn
	 */
	public int getTurn() {
		return this.turn;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Postcondition</b> Increases turn by 1
	 */
	public void nextTurn() {
		this.turn++;
	}

	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition</b> Checks if a CharacterCard is being played
	 * @return true if some CharacterCard has been played
	 */
	public boolean getCharacterIsPlayed() {
		return this.characterIsPlayed;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Postcondition</b> Sets the characterCharacterIsPlayed field of the board
	 * @param b boolean true or false
	 */
	public void setCharacterIsPlayed(boolean b) {
		this.characterIsPlayed = b;
	}
	
	/**
	 * <b>Transformer</b><br>
	 * <b>Postcondition</b> Adds a tile on the board
	 * @param tile the tile to add
	 */
	public void addTile(Tile tile) {
		
		try {
			if (tile instanceof AmphoreasTile) this.amphoreasArea.addTile(tile);
			else if (tile instanceof SkeletonTile) this.skeletonArea.addTile(tile);
			else if (tile instanceof StatueTile) this.statueArea.addTile(tile);
			else if (tile instanceof MosaicTile) this.mosaicArea.addTile(tile);
			else if (tile instanceof RockTile) this.rockArea.addTile(tile);
			
		}catch(Exception e) {System.err.println(e);}
	}
	
	/**
	 * <b>Transformer</b><br>
	 * <b>Postcondition</b> Removes a tile from the board
	 * @param tile the tile to remove
	 */
	public void removeTile(Tile tile) {
		try {
			if (tile instanceof AmphoreasTile) this.amphoreasArea.removeTile(tile);
			else if (tile instanceof SkeletonTile) this.skeletonArea.removeTile(tile);
			else if (tile instanceof StatueTile) this.statueArea.removeTile(tile);
			else if (tile instanceof MosaicTile) this.mosaicArea.removeTile(tile);
			else if (tile instanceof RockTile) this.rockArea.removeTile(tile);
			
		}catch(Exception e) {System.err.println(e);}
	}
	/**
	 * <b>Accessor</b> This is the condition to end the game.
	 * <b>Postcondition:</b> Checks if the game is over (i.e. if the rock area is full)
	 * @return true or false
	 */
	public boolean isGameComplete() {
		return this.rockArea.size() >= RockAreaCapacity;
	}
	
	
}
