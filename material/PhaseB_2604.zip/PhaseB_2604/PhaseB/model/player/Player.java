package model.player;

import java.util.ArrayList;
import java.util.HashSet;

import model.card.*;
import model.tile.*;
import model.tileCollection.*;


/**
 * Class that describes the player in the game
 * @author tem2604
 *
 */
public class Player {
	
	private String name;
	private boolean hasPlayed;
	private int position;
	private TileCollection amphorasCollection,mosaicCollection,skeletonCollection,statueCollection;
	private int mostKaryatides, mostSphinx;
	
	private int points;
	private CharacterCard[] cards = {new ArcheologistCard(),new AssistantCard(), new ProfessorCard(), new DiggerCard()};
	
	
	/**
	 * <b>Constructor</b>
	 * <b>Precondition:</b> Player must be given a name<br> Position on the board is 0,1,2 or 3 with 0 for the first position and moving couner-clockwise
	 * <b>Postcondition:</b> Creates new Player with name and position 0,1,2,3
	 * @param name	The name of the player
	 * @param position Integer 0,1,2,3
	 */
	public Player(String name, int position) {
		this.name = name;
		this.position = position;
		this.hasPlayed = true;
		this.mostKaryatides = 0;
		this.mostSphinx = 0;
		this.amphorasCollection = new TileCollection();
		this.skeletonCollection = new TileCollection();
		this.mosaicCollection = new TileCollection();
		this.statueCollection = new TileCollection();
		
	}
	
	
	public TileCollection getAllTiles() {
		TileCollection col = new TileCollection();
		for (int i = 0; i < this.amphorasCollection.size(); i++) {
			col.addTile(this.amphorasCollection.getTile(i));
			
		}
		for (int i = 0; i < this.mosaicCollection.size(); i++) {
			col.addTile(this.mosaicCollection.getTile(i));
			
		}
		for (int i = 0; i < this.skeletonCollection.size(); i++) {
			col.addTile(this.skeletonCollection.getTile(i));
			
		}
		for (int i = 0; i < this.statueCollection.size(); i++) {
			col.addTile(this.statueCollection.getTile(i));
			
		}
		return col;
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Precondition:</b> The player has a name
	 * <b>Postcondition:</b> Gets the name of the player
	 * @return The name of the player
	 */
	public String getName() {
		return this.name;
	}
	
	
	/**
	 * <b>Transformer</b>
	 * <b>Postcondition:</b> Sets the name of the player
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Gets the statue tile collection of the player<br>
	 * @return the tile collection of statue tiles
	 */
	public TileCollection getStatueCollection() {
		return this.statueCollection;
	}
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Gets the amphora tile collection of the player<br>
	 * @return the tile collection of amphora tiles
	 */
	
	public TileCollection getAmphorasCollection() {
		return this.amphorasCollection;
	}
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Gets the mosaic tile collection of the player<br>
	 * @return the tile collection of mosaic tiles
	 */

	public TileCollection getMosaicCollection() {
		return this.mosaicCollection;
	}
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Gets the skeleton tile collection of the player<br>
	 * @return the tile collection of skeleton tiles
	 */

	public TileCollection getSkeletonCollection() {
		return this.skeletonCollection;
	}
	
	/**
	 * <b>Accessor</b> 
	 * <b>Precondition:</b> the player must have a position
	 * <b>Postcondition:</b> Gets the position of the player
	 * @return The position of the player 0,1,2 or 3 
	 */
	public int getPosition() {
		return this.position;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Postcondition:</b> Sets the position of the player
	 * @param i the new position i = 0,1,2,3
	 */
	public void setPosition(int i) {
		this.position = i;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> Tile is a finding tile 
	 * <b>Postcondition</b> Tile is added to the proper tile collection of the player
	 * @param tile	the tile to take
	 */
	public void takeTile(FindingTile tile) {
		if (tile instanceof AmphoreasTile) this.amphorasCollection.addTile((AmphoreasTile) tile);
		else if (tile instanceof MosaicTile) this.mosaicCollection.addTile((MosaicTile) tile);
		else if (tile instanceof SkeletonTile) this.skeletonCollection.addTile((SkeletonTile) tile);
		else if (tile instanceof StatueTile) this.statueCollection.addTile((StatueTile) tile);
	
	}
	
	
	/**
	 * <b>Observer</b>
	 * <b>Postcondition:</b> Get the points of the player
	 * @return The points of the player
	 */
	public int getPoints() {
		return this.points;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> Points must not be negative
	 * <b>Postcondition:</b> Sets the points f the player
	 * @param points points>=0
	 * 
	 */
	public void setPoints(int points) {
		this.points = points;
	}
	


	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Get the cards that a player has
	 * @return An array that contains the cards that a player has
	 */
	public CharacterCard[] getCards() {
		return this.cards;
	}
	
	

	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> Card is not already used
	 * <b>Postcondition:</b> Card is declared used
	 * @param card The card to use
	 */
	public void useCard(CharacterCard card) {
		for (int i = 0; i < this.cards.length; i++) {
			if (cards[i].equals(card) && !cards[i].isUsed()) {
				cards[i].setUsed(true);
			}

		}
	}
	
	
	/**
	 * <b>Observer</b>
	 * <b>Postcondition:</b> Checks if the player has completed their turn in order to continue to next player
	 * @return	true if the player has completed actions, false otherwise
	 */
	public boolean hasPlayed() {
		return this.hasPlayed;
	}

	
	/**
	 * Override the equals method
	 */
	public boolean equals(Object o2) {
		if (o2 instanceof Player) {
			return this.name == ((Player) o2).getName();
		}
		return false;
	}
	
	/**
	 * <b>Transformer</b> Sets how many statues of type statueType the player has relatively to the other players<br> It sets the appropriate variables 0, 1 or 2
	 * <b>Precondition</b>	The statueType is "KARYATIDA" or "SPHINX"<br> i is 0,1 or 2
	 * <b>Postcondition:</b> Set the variables mostKaryatides or mostSphinx the value of i
	 * @param statueType "KARYATIDA" or "SPHINX"
	 * @param i i = 0, 1 or 2
	 */
	public void setMostStatue(String statueType,int i) {
		if (statueType.equals("KARYATIDA")) {
			this.mostKaryatides = i;
		}
		else if (statueType.equals("SPHINX")){
			this.mostSphinx  =i;
		}
	}
	
	/**
	 * <b>Observer</b> Gets how many statues of statueType the player has relatively to the other players<br> 
	 * <b>PreconditionL</b> The statueType is "KARYATIDA" or "SPHINX"<br>   
	 * @param statueType "KARYATIDA" or "SPHINX"
	 * @return relative amount of statues
	 */
	public int getMostStatue(String statueType) {
		if (statueType.equals("KARYATIDA")) {
			return this.mostKaryatides;
		}
		else if (statueType.equals("SPHINX")){
			return this.mostSphinx;
		}
		return -1;
	}

	
	
	
	/**
	 * <b>Precondition</b> We knoe how many statues the player has relatively to the others
	 * <b>Postcondition</b> Counts the points of the player according to the tiles they have
	 * @return the points that the player has
	 */
	public void countPoints() {

		
		int kpoints = this.mostKaryatides*3;
		int spoints = this.mostSphinx*3;
		int result = this.countAmphoreasPoints() + kpoints + spoints +countMosaicPoints() + countSkeletonPoints();
		this.points = result;
				

	}
	
	
	/*
	 * Private method that counts the points concerning the skeleton tiles
	 */
	private int countSkeletonPoints(){
		int smallTop = 0;int bigTop = 0;int smallBot = 0; int bigBot = 0;
		int result = 0;
		int completedBig;
		int completedSmall;
		int bigByPairs;
		int totalFamilies;
		//first we count the completed ones , then the families
		SkeletonTile tile;
		for (int i = 0; i < skeletonCollection.size(); i++) {
			tile = (SkeletonTile) skeletonCollection.getTile(i);
			if (tile.getaPart() == 0) {
				if (tile.getSize() == 0) smallTop++;
				else bigTop++;
				
			}
			else {
				if (tile.getSize() == 0) smallBot++;
				else bigBot++;
			}
		}
		
		completedBig = (bigTop > bigBot)? bigBot:bigTop;
		completedSmall = (smallTop>smallBot) ? smallBot:smallTop;
		
		bigByPairs = completedBig/2;
		
		totalFamilies = (bigByPairs > completedSmall) ? completedSmall : bigByPairs;
		
		result += totalFamilies*6;
		
		result += (completedBig - totalFamilies*2) + (completedSmall - totalFamilies);
		return result;
	}
	
	/*
	 * Private method that counts he points cconcerning the mosaic tiles
	 */
	private int countMosaicPoints() {
		int total = 0;
		int red = 0;
		int yellow = 0;
		int green = 0;
		MosaicTile tile;
		for (int i = 0; i < this.mosaicCollection.size(); i++) {
			tile = (MosaicTile) this.mosaicCollection.getTile(i);
			if (tile.getColour() == MosaicColour.GREEN) green++;
			else if (tile.getColour() == MosaicColour.RED) red++;
			else yellow++;
			
		}
		
		
		total += (green/4)*4 + (red/4)*4 + (green/4)*4;
		red = red%4;
		green = green%4;
		yellow = yellow%4;
		
		int remaining = red + green + yellow;
		
		total += (remaining/4)*2;
		
				
		
		return total;
		
	}
	
	/*
	 * Private method that counts he points concerning the amphora tiles
	 */
	private int countAmphoreasPoints() {
		AmphoreasTile tile;
		HashSet colours = new HashSet();
		

		for (int i = 0; i < this.amphorasCollection.size(); i++) {
			tile = (AmphoreasTile) this.amphorasCollection.getTiles().get(i);
			colours.add((AmphoreasColour) tile.getColour());
		}
		return colours.size();
	}
	
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Counts the number of statue tiles of the player of the specific type
	 * @param type KARYATIDA of SPHINX
	 * @return the number of tiles
	 */
	public int statueCounter(String type) {
		int counter = 0;
		for (int i = 0; i < this.statueCollection.size(); i++) {
			if (((StatueTile) this.statueCollection.getTile(i)).getType().equals(type)) {
				counter ++;
			}
		}
		return counter;
	}
	

	
}











