package model.bag;
import java.util.ArrayList;

import model.card.*;
import model.tile.*;
import java.util.Random;


/**
 * Class that represents the bag in the game
 * @author tem2604
 *
 */
public class Bag {
	private ArrayList<Tile> tiles;
	
	/**
	 * <b>Constructor</b>
	 */
	public Bag() {
		this.tiles = new ArrayList<Tile>();
	}
	
	
	/**
	 * <b>Transformer</b> Adds a tile in the bag
	 * <b>Precondition</b> Bag is not full
	 * @param tile Tile object
	 */
	public void addTile(Tile tile) {
		this.tiles.add(tile);
	}
	
	/**
	 * <b>Transformer:</b> Removes a tile from the bag
	 * <b>Precondition</b> Bag is not empty
	 * @param tile Tile object
	 */
	public void removeTile(Tile tile) {
		this.tiles.remove(tile);
	}

	/**
	 * <b>Observer:</b> Takes the tiles in the bag
	 * 
	 * @return ArrayList of the tiles in the bag
	 */
	public ArrayList<Tile> getTiles(){
		return this.tiles;
	}
	
	/**
	 * <b>Transformer</b> 
	 * <b>Precondition</b> Bag not empty
	 * <b>Postcondition</b> takes a random Tile from the bag and removes it
	 * @return the tile was picked in random
	 */
	public Tile giveRandomTile() {
		Random random = new Random();
		int i;
		i = random.nextInt(this.tiles.size());
		Tile tile = this.tiles.get(i);
		this.tiles.remove(i);
		return tile;
	}
	
	/**
	 * <b>Observer</b> Checks if the bag is empty
	 * <b>Precondition</b> Bag must be initiated
	 * @return true if the bag is empty, false otherwise
	 */
	public boolean isEmpty() {
		return this.tiles.size() == 0;
	}
	
	
	//public boolean isFull() {}
	
}
