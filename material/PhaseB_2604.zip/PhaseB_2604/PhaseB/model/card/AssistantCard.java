package model.card;

/**
 * Class that represents the AssistantCard
 * @author tem2604
 *
 */
public class AssistantCard extends CharacterCard{
	
	
	/**
	 * <b>Constructor</b> Creates an unused Card
	 * 
	 */
	
	public AssistantCard() {
		this.used = false;
	}
	
	/**
	 * Override the toString method
	 */
	public String toString() {
		return "Assistant card: Take 1 tile from any area"; 
	}
	
	/**
	 * Override the equals method
	 */
	public boolean equals(Object o2) {
		if (o2 instanceof AssistantCard) return true;
		return false;
	}
	
}
