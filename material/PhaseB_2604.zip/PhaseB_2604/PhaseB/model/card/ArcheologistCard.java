package model.card;

/**
 * Class that describes the ArcheologistCard
 * @author tem2604
 *
 */
public class ArcheologistCard extends CharacterCard {
	
	/**
	 * <b>Constructor</b> Creates an unused Card
	 * 
	 */
	public ArcheologistCard() {
		this.used = false;
	}
	
	
	/**
	 * Override the toString method
	 */
	public String toString() {
		return "Archeologist card: Take 2 tiles from any other area"; 
	}


	/**
	 * Override the equals method
	 */
	public boolean equals(Object o2) {
		if (o2 instanceof ArcheologistCard) return true;
		return false;
	}

}
