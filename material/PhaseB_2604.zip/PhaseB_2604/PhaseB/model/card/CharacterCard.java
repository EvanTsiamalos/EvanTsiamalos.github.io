package model.card;



import model.player.*;

/**
 * Abstract class that represents the Character cards in the game
 * @author tem2604
 *
 */
public abstract class CharacterCard {
	
	protected boolean used;
	private Player holder;
	
	
	/**
	 * <b>Observer:</b> Checks if the card has been used
	 * <b>Postcondition:</b> Tells if the card is used
	 * @return true if the card has been used
	 */
	public boolean isUsed() {
		return this.used;
	}
	/**
	 *<b>Transformer:</b> Sets the card used or unused
	 *
	 *<b>Postcondition</b> The card is declared used or unused
	 * @param b true or false
	 */
	public void setUsed(boolean b) {
		this.used = b;
	}
	
	
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> p is not null
	 * <b>Postcondition:</b> holder is set
	 * @param p the player to hold the card
	 */
	public void setHolder(Player p) {this.holder = p;}
	
	/**
	 * <b>Observer</b>
	 * <b>Postcondition</b> gets the holder of the card
	 * @return holder of the card
	 */
	public Player getHolder() {
		return this.holder;
	}
	
	public abstract boolean equals(Object o2);
	
	public abstract String toString();
}
