package model.card;

/**
 * Class that represents the professor card
 * @author tem2604
 *
 */
public class ProfessorCard extends CharacterCard{

	/**
	 * <b>Constructor</b> Creates an unused card
	 */
	public ProfessorCard() {
		this.used = false;
	}
	
	/**
	 * Override the toString method
	 */
	@Override
	public String toString() {
		return "Professor Card: Pick one tile from every area of he board";
	}
	
	/**
	 * Override the equals method
	 */
	@Override
	public boolean equals(Object o2) {
		if (o2 instanceof ProfessorCard) return true;
		return false;
	}
}
