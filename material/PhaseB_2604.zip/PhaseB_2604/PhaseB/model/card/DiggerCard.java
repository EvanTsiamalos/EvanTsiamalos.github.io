package model.card;

/**
 * Class that represents the digger card
 * @author Public-IT
 *
 */
public class DiggerCard extends CharacterCard {
	
	/**
	 * <b>Constructor</b> Creates an unused card
	 */
	public DiggerCard() {
		this.used = false;
	}
	

	/**
	 * Override the toString method
	 */
	public String toString() {
		return "Digger catd: Take up to 2 tile from the previous area";
	}
	
	/**
	 * Override the equals method
	 */
	public boolean equals(Object o2) {
		if (o2 instanceof DiggerCard) return true;
		return false;
	}
	
}
