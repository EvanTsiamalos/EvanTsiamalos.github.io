package controller;

import java.util.ArrayList;
import java.util.*;

import model.bag.*;
import model.board.*;
import model.card.*;
import model.player.*;
import model.tile.*;
import model.tileCollection.*;

/**
 * Class that handles all the controls of the game connecting the core and the graphic interface.
 * @author tem2604
 *
 */
public class Controller {
	private int positionPlaying; // The position that plays 0 1 2 3
	private CharacterCard cardUsed; 
	private Board board;
	private int areaPlayed;
	private Player p1,p2,p3,p4;
	private Player[] players;
	private int tilesTaken;		
	private int tileRemoveLimit;
	private Bag bag;
	private ArrayList<Tile> tilesChosen;
	private boolean cardWasPlayed;
	private Random random = new Random();
	private String allowedAreas;
	
	/**
	 *<b>Constructor</b>
	 *<b>Postcondition:</b> Initializes the board and the players, gives the playing positions to the players 
	 */
	public Controller() {
		this.p1 = new Player("South",0);
		this.p2 = new Player("East",1);
		this.p3 = new Player("North",2);
		this.p4 = new Player("West",3);		
		
		this.players = new Player[4];
		this.players[0] = this.p1;
		this.players[1] = this.p2;
		this.players[2] = this.p3;
		this.players[3] = this.p4;

		this.tilesChosen = new ArrayList<Tile>();
		this.bag = new Bag();
		this.board = new Board();		
	}
	
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Gets the the maximum number of tiles one can take from the board<br>
	 * @return the maximum number
	 */
	public int getTileRemoveLimit() {
		return this.tileRemoveLimit;
	}
	
	/**
	 * <b>Transformer</b><br>
	 * <b>Postcondition</b> Sets the TileRemoveLimit
	 * 
	 * @param i Integer greater than zero
	 */
	public void setTileRemoveLimit(int i) {
		this.tileRemoveLimit = i;
	}
	
	
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Checks if a card is being used
	 * @return True if a card is being used
	 */
	public boolean getCardWasPlayed() {
		return this.cardWasPlayed;
	}
	/**
	 * <b>Transformer</b><br>
	 * <b>Postcondition</b> Sets the cardWasPlayed
	 * @param b true or false
	 */
	public void setCardWasPlayed(boolean b) {
		this.cardWasPlayed = b;
	}
	
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Gets the bag of the game</b>
	 * @return the bag of the game
	 */
	public Bag getBag() {return this.bag;}
	/**
	 * <b>Accessor</b>
	 * <b>Precondition</b> i = 0,1,2,3
	 * <b>Postcondition</b> Return the player sitting on position i	
	 * @param i The position of the player
	 * @return The player sitting on position i
	 */
	public Player getPlayer(int i) {
		return this.players[i];
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition</b> Gets the board of the game
	 * @return the board
	 */
	public Board getBoard() {
		return this.board;
	}
	
	/**
	 * It is called every time the player has selected the tiles that they want to pick up from the board<br> It updates the player's collections and the board
	 * <b>Precondition:</b> The amount of tiles taken is legal
	 * <b>Postcondition:</b> The player adds the tiles to their collections
	 */
	public void pickTiles() {
		Tile tile;
		for (int i = 0; i < tilesChosen.size(); i++) {
			tile = tilesChosen.get(i);
			players[this.positionPlaying].takeTile((FindingTile) tile);
			board.removeTile(tile);
			
		}
		
		
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition</b> Returns the tiles chosen to be picked up from the board
	 * @return The ArrayList of Tiles that have been chosen
	 */
	public ArrayList<Tile> getTilesChosen() {
		return this.tilesChosen;
	}
	
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition</b> The tileRemoveLimit has not been exceded
	 * <b>Postcondition</b> The tile is added in the tilesChosen ArrayList
	 * @param tile The Tile to ad in the tilesChosen
	 */
	public void chooseTile(Tile tile) {
		if (this.tileRemoveLimit > this.tilesChosen.size()){
			this.tilesChosen.add(tile);
		
		
		}
		else System.out.println("Limit reached");
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition:</b> Tile is in the tilesChosen ArrayList
	 * <b>PostCondition:</b> Removes the tile from the tilesChosenArrayList
	 * @param tile the tile to remove from the tilesChosen ArrayList
	 */
	
	public void removeChosenTile(Tile tile) {
		this.tilesTaken--;
		this.tilesChosen.remove(tile);}
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Checks if the bag is empty
	 * @return true if the bag is empty
	 */
	public boolean isBagEmpty(){ return this.bag.isEmpty();}
	
	/**
	 * Takes a random Tile from the bag
	 * <b>Precondition:</b> The bag is not empty
	 * <b>Postcondition:</b> Gets a tile from the bag
	 * @return A random tile
	 */
	public Tile getBagTile() {
		return this.bag.giveRandomTile();
	}

	/**
	 * Method responsible for preparing the game.<br> It takes 4 tiles from the bag, one for each area, and places them on the board.
	 * <b>Postcondition:<b> The game is ready to start.
	 */
	public void initGame() {
		for (int i = 0; i < 9; i++) {
			this.bag.addTile(new MosaicTile(MosaicColour.GREEN));
			this.bag.addTile(new MosaicTile(MosaicColour.RED));
			this.bag.addTile(new MosaicTile(MosaicColour.YELLOW));
		}
		
		for (int j = 0; j<12; j++) {
			this.bag.addTile(new StatueTile("KARYATIDA"));
			this.bag.addTile(new StatueTile("SPHINX"));
		}
		
		for (int u = 0; u < 24; u++) {
			this.bag.addTile(new RockTile());
			
		}
		
		for (int s = 0; s < 10; s++) {
			this.bag.addTile(new SkeletonTile(1,1));
			this.bag.addTile(new SkeletonTile(1,0));
			
		}
		
		for (int z= 0; z < 5; z++) {
			this.bag.addTile(new SkeletonTile(0,1));
			this.bag.addTile(new SkeletonTile(0,0));
			this.bag.addTile(new AmphoreasTile(AmphoreasColour.BLUE));
			this.bag.addTile(new AmphoreasTile(AmphoreasColour.BROWN));
			this.bag.addTile(new AmphoreasTile(AmphoreasColour.GREEN));
			this.bag.addTile(new AmphoreasTile(AmphoreasColour.PURPLE));
			this.bag.addTile(new AmphoreasTile(AmphoreasColour.RED));
			this.bag.addTile(new AmphoreasTile(AmphoreasColour.YELLOW));
		}
		
		

		this.positionPlaying = random.nextInt(4); //the player to start playing
		this.tileRemoveLimit = 2;
		this.tilesTaken=0;
		board.setCharacterIsPlayed(false);
		this.cardWasPlayed = false;
		
		
		try {
			for (int i = 0; i < 4; i++) {
					Tile tile = bag.giveRandomTile();
					board.addTile(tile);
			}
		}catch(Exception e) {System.err.println(e);}	
		
		

	}
	
	/**
	 * <b>Transformer</b><br>
	 * <b>Precondition</b> The bag is not empty<br>
	 * <b>Postcondition</b> Draws for tiles from the bag<br>
	 */
	public void drawTiles() {
		
		int i = 0;
		
		while (i < 4 && !this.bag.isEmpty()) {
			board.addTile(this.bag.giveRandomTile());
			i++;
		}
		
		
		if (bag.isEmpty()) {System.out.println("Bag emoty");}
	}
	
	
	/**
	 * <b>Accessor</b> <br>
	 * <b>Postcondition:</b> Gets all the tiles from the board<br>
	 * @return A tileCollection with all the tiles from the board
	 */
	public TileCollection getAllBoardTiles() {
		TileCollection result = new TileCollection();
		for (int i = 0; i < this.board.getAmphoreasArea().size(); i++) {
			result.addTile(board.getAmphoreasArea().getTile(i));
		}
		for (int i = 0; i < this.board.getMosaicArea().size(); i++) {
			result.addTile(board.getMosaicArea().getTile(i));
		}
		for (int i = 0; i < this.board.getSkeletonArea().size(); i++) {
			result.addTile(board.getSkeletonArea().getTile(i));
		}
		for (int i = 0; i < this.board.getRockArea().size(); i++) {
			result.addTile(board.getRockArea().getTile(i));
		}
		for (int i = 0; i < this.board.getStatueArea().size(); i++) {
			result.addTile(board.getStatueArea().getTile(i));
		}
		return result;
		
	}
	/**
	 * <b>Transformer</b>
	 * <b>Postcondition:</b> Sets the playing position on the board 0,1,2,3
	 * @param i i = 0,1,2,3
	 */
	public void setPositionPlaying(int i) {
		this.positionPlaying = i;
	}
	
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the position on the board that is playing
	 * @return the position on the board that is playing
	 */
	public int getPositionPlaying() {
		return this.positionPlaying;
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Precondition:</b> the areaPlayed must be initialized
	 * <b>Postcondition:</b> gets the TileArea of the board that the player has chosen to pick tiles from
	 * @return the area played 0,1,2 or 3
	 */
	public int getAreaPlayed() {
		return this.areaPlayed;
	}
	/**
	 * <b>Accessor</b>
	 * <b>Precondition:</b> the areaPlayed must be initiallized
	 * <b>Postcondition:</b> gets the TileArea of the board that the player has chosen to pick tiles from
	 * @param area the area 0,1,2,3
	 * 
	 */
	public void setAreaPlayed(int area) {
		this.areaPlayed = area;
	}
	
	
	
	
	
	/**
	 * <b>Postcondition:</b> Moves on to the next turn
	 */
	public void endTurn() {
		
		
		this.areaPlayed = -1;
		this.positionPlaying = (this.positionPlaying + 1)%4; 
		this.cardWasPlayed = false;
		this.tilesChosen = new ArrayList<>();
		this.tileRemoveLimit = 2;
	} 
	
	/**
	 * <b>Observer</b>
	 * <b>Postcondition:</b> Checks if a card has been used
	 * @return true if a card has been used
	 */
	public boolean isCardUsed() {
		return board.getCharacterIsPlayed();
	}
	
	/**
	 * <b>Precondition:</b> the card is not used
	 * <b>Postcondition:</b> Implements the actions of playing a card
	 * @param card CharacterCard
	 */
	public void useCard(CharacterCard card) {
		CharacterCard cardOfPlayer = this.getplayerCard(card);
		
		if (!cardOfPlayer.isUsed() && !cardWasPlayed) {
			cardWasPlayed = true;
			if (card instanceof ArcheologistCard) {
				// make a string of allowed areas
				this.allowedAreas = "";
				for (int i = 0; i < 4; i++) {
					if (! (i == this.areaPlayed)) this.allowedAreas += i;
				}
				
				
			}
			else if (card instanceof AssistantCard) {
				this.allowedAreas = "0123";
				this.tileRemoveLimit = 1;
			}
			
			else if (card instanceof DiggerCard) {
				this.tileRemoveLimit = 2;
				this.allowedAreas = "" + this.areaPlayed;
			}
			else if (card instanceof ProfessorCard) {
				tileRemoveLimit = 3;
				this.allowedAreas = "";
				for (int i = 0; i < 4; i++) {
					if (! (i == this.areaPlayed)) this.allowedAreas += i;
				}
				
			}
			this.tilesChosen = new ArrayList<>();
		}
		

		this.cardUsed = card;
		this.players[positionPlaying].useCard(card);
		this.cardWasPlayed = true;
	}
	
	/**
	 * <b>Transformer</b><br>
	 * <b>Postcondition</b> Sets the card that is being used
	 * @param card the card used
	 */
	public void setCardUsed(CharacterCard card) {
		this.cardUsed = card;
	}
	
	/**
	 * <b>Observer</b><br>
	 * <b>Postcondition</b> Gets the card that is being used
	 * @return The card that is being used
	 */
	public CharacterCard getCardUsed() {
		return this.cardUsed;
	}
	
	/**
	 * <b>Observer</b><br>
	 * <b>Postcondition</b> Gets the allowed areas from where a player can take a tile whule using a character
	 * @return The allowed areas
	 */
	public String getAllowedAreas() {
		return this.allowedAreas;
	}
	
	/**
	 * <b>Transformer</b><br>
	 * <b>Precondition</b> Requires a string that containsthe integers from 0 to 3<br>
	 * <b>Postcondition</b> Sets the allowed areas<br>
	 * @param s the string of the allowed areas
	 */
	public void setAllowedAreas(String s) {
		this.allowedAreas = s;
	}
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Checks if the game is ended
	 * @return true if the game is ended
	 */
	public boolean isGameEnded() {
		return this.board.isGameComplete();
	}
	
	/**
	 * <b>Precondition:</b> The game must be over
	 * <b>Postcondition:</b> Counts the points and returns the announcement of the points and the winner
	 * @return A string with the endgame information
	 */
	public String endGame() {
				
			int maxkarCounts;
			int minkarCounts;
			int minKarIndex = 0;
			int maxKarIndex = 0;
			
			for (int i = 0; i < 4; i ++) {
				if (this.players[minKarIndex].statueCounter("KARYATIDA") > this.players[i].statueCounter("KARYATIDA")) {
					minKarIndex = i;
				}
				if (this.players[maxKarIndex].statueCounter("KARYATIDA") < this.players[i].statueCounter("KARYATIDA") ) {
					maxKarIndex = i;
				}
			}
			
			
			maxkarCounts = this.players[maxKarIndex].statueCounter("KARYATIDA");
			minkarCounts = this.players[minKarIndex].statueCounter("KARYATIDA");

			for (int j = 0; j < 4; j++) {
				if (this.players[j].statueCounter("KARYATIDA") > 0) {	
					if (this.players[j].statueCounter("KARYATIDA") == maxkarCounts) {
						players[j].setMostStatue("KARYATIDA", 2);
					}
					else if (this.players[j].statueCounter("KARYATIDA") == minkarCounts) {
						players[j].setMostStatue("KARYATIDA", 0);
					}
					else players[j].setMostStatue("KARYATIDA", 1);
				}
	
			}
			
			
			int maxsphCounts, minsphCounts;
			int minSphIndex = 0;
			int maxSphIndex = 0;
			
			for (int i = 0; i < 4; i ++) {
				if (this.players[minSphIndex].statueCounter("SPHINX") > this.players[i].statueCounter("SPHINX")) {
					minSphIndex = i;
				}
				if (this.players[maxSphIndex].statueCounter("SPHINX") < this.players[i].statueCounter("SPHINX")) {
					maxSphIndex = i;
				}
			}
			
			
			maxsphCounts = this.players[maxSphIndex].statueCounter("SPHINX");
			minsphCounts = this.players[minSphIndex].statueCounter("SPHINX");
			
			for (int j = 0; j < 4; j++) {
				if (this.players[j].statueCounter("SPHINX")>0){
					if (this.players[j].statueCounter("SPHINX") == maxsphCounts) {
						players[j].setMostStatue("SPHINX", 2);
					}
					else if (this.players[j].statueCounter("SPHINX") == minsphCounts) {
						players[j].setMostStatue("SPHINX", 0);
					}
					else players[j].setMostStatue("SPHINX", 1);
				}
				
			}			

			players[0].countPoints();
			players[1].countPoints();
			players[2].countPoints();
			players[3].countPoints();
			
			System.out.println(players[0].getName() + " " + players[0].getPoints());
			System.out.println(players[1].getName() + " " + players[1].getPoints());
			System.out.println(players[2].getName() + " " + players[2].getPoints());
			System.out.println(players[3].getName() + " " + players[3].getPoints());
			
			String[] names = new String[4];
			int[] points = new int[4];
			
			for (int i = 0; i <4 ; i ++) {
				names[i] = players[i].getName();
				points[i] = players[i].getPoints();
			}
			
			int tempPoint;
			int minInd;
			String tempPlayer;
			for (int i = 0; i < 3; i++) {
				minInd = i;
				for (int j = i+1; j < 4; j++) {
					if (points[j]< points[minInd]) {
						minInd = j;
					}
					
				}
				tempPlayer = names[minInd];
				names[minInd] = names[i];
				names[i] = tempPlayer;				//!!! Do change the players as well in the this.players table
				
				tempPoint = points[minInd];
				points[minInd] = points[i];
				points[i] = tempPoint;
			}
			String ann = "The results of the game: " + 
					"\n First Place: " + names[3] + " with " + points[3] +
					"\n Second Place: " + names[2] + " with " + points[2] +
					"\n Third Place: " +names[1] + " with " + points[1] +
					"\n Fourth Place: " + names[0] + " with " + points[0];
			return ann;
	}
	
	
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition</b> Gets the character card of the plaer playing
	 * @param c the card we are looking for
	 * @return the card of the player playing
	 */
	public CharacterCard getplayerCard(CharacterCard c) {
		CharacterCard result = new ArcheologistCard();
		
		for (int i = 0; i < 4; i++) {
			if (this.players[positionPlaying].getCards()[i].equals(c)) {
				result = this.players[positionPlaying].getCards()[i];
				break;
			}
		}
		
		return result;
		
		
	}
	
	
}
	


