package viewer;
import javax.swing.*;
import model.tile.*;


/**
 * Class that is going to be used to represent the tile blocks on the board.<br> It extends JLabel and they contain a private Tile object that represents the tile that they represent
 * @author tem2604
 *
 */
public class TileBlock extends JLabel implements Cloneable{
	private Tile tile;  // the tile they represent
	
	private int area; // 0 ,1 ,2, 3, 4 (4 is the rock area)
	
	/**
	 * <b>Constructor</b>
	 * <b>Precondition:</b> The area is 0,1,2,3 or 4 and is the area that the tile should belong to. 
	 * <b>Postcondition:</b> It constructs the TileBlock that represents the Tile tile at specified area
	 * @param tile the tile to relate to the TileBlock
	 * @param area the area of the tile 0,1,2,3 or 4
	 */
	public TileBlock(Tile tile) {
		
		this.tile = tile;

		
		if (tile instanceof AmphoreasTile) {
			this.area = 3;
			if ((((AmphoreasTile) tile).getColour()).equals(AmphoreasColour.BLUE)){
				this.setIcon(new ImageIcon("images_editted\\amphora_blue30x30.png"));
			}
			else if ((((AmphoreasTile) tile).getColour()).equals(AmphoreasColour.RED)){
				this.setIcon(new ImageIcon("images_editted\\amphora_red30x30.png"));
			}
			else if ((((AmphoreasTile) tile).getColour()).equals(AmphoreasColour.GREEN)){
				this.setIcon(new ImageIcon("images_editted\\amphora_green30x30.png"));
			}
			else if ((((AmphoreasTile) tile).getColour()).equals(AmphoreasColour.PURPLE)){
				this.setIcon(new ImageIcon("images_editted\\amphora_purple30x30.png"));
			}
			else if ((((AmphoreasTile) tile).getColour()).equals(AmphoreasColour.BROWN)){
				this.setIcon(new ImageIcon("images_editted\\amphora_brown30x30.png"));
			}
			else if ((((AmphoreasTile) tile).getColour()).equals(AmphoreasColour.YELLOW)){
				this.setIcon(new ImageIcon("images_editted\\amphora_yellow30x30.png"));
			}
		}
		
		else if (tile instanceof SkeletonTile) {
			this.area = 0;
			if (((SkeletonTile) tile).getaPart()==0) {
				if (((SkeletonTile) tile).getSize()==0) {
					this.setIcon(new ImageIcon("images_editted\\skeleton_small_top30x30.png"));
				}
				else this.setIcon(new ImageIcon("images_editted\\skeleton_big_top30x30.png"));
			}
			else {
				if (((SkeletonTile) tile).getSize()==0) {
					this.setIcon(new ImageIcon("images_editted\\skeleton_small_bot30x30.png"));
				}
				else this.setIcon(new ImageIcon("images_editted\\skeleton_big_bot30x30.png"));
			}
		}
		
		else if (tile instanceof MosaicTile) {
			this.area = 2;
			if ((((MosaicTile) tile).getColour()).equals(MosaicColour.GREEN)){
				this.setIcon(new ImageIcon("images_editted\\mosaic_green30x30.png"));
			}
			else if ((((MosaicTile) tile).getColour()).equals(MosaicColour.RED)){
				this.setIcon(new ImageIcon("images_editted\\mosaic_red30x30.png"));
			}
			else if ((((MosaicTile) tile).getColour()).equals(MosaicColour.YELLOW)){
				this.setIcon(new ImageIcon("images_editted\\mosaic_yellow30x30.png"));
			}
		}
		
		else if (tile instanceof StatueTile) {
			this.area = 1;
			if ((((StatueTile)tile).getType()).equals("KARYATIDA")){
				this.setIcon(new ImageIcon("images_editted\\karyatida30x30.png"));
			}
			else {this.setIcon(new ImageIcon("images_editted\\sphinx30x30.png"));}
		}
		else {
			this.area = 4;
			this.setIcon(new ImageIcon("images_editted\\rock38x38.png"));
		}
		
		this.setToolTipText(tile.toString());
	}
	
	
	public TileBlock(Tile tile, int area,ImageIcon im) {
		super(im);
		this.area=area;
		this.tile = tile;
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Postcondition:</b> Gets the tile 
	 * @return the tile
	 */
	public Tile getTile() {
		return this.tile;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Postcondition:</b> Sets the tile
	 * @param tile  the tile to set
	 */
	public void setTile(Tile tile) {
		this.tile = tile;
	}
	
	/**
	 * <b>Accessor</b>
	 * <b>Precondition</b> The tile is on the board
	 * <b>Postcondition</b> Gets the area on which the tile lies
	 * @return the area
	 */
	public int getArea() {
		return this.area;
	}
	
	/**
	 * <b>Transformer</b>
	 * <b>Precondition</b> The tile is on the board
	 * <b>Postcondition</b> Sets the area
	 * @param i i = 0,1,2,3,4
	 */
	public void setArea(int i) {
		this.area = i;
	}
	
	/**
	 * <b>Accessor</b> 
	 * <b>Postcondition</b> Returns information for the TileBlock
	 * @return information for the TileBlock
	 */
	public String getInfo() {
		return this.tile.toString();
	}
	
	/**
	 * Override the equals method
	 */
	public boolean equals(Object o2) {
		if (o2 instanceof TileBlock) {
			TileBlock tb = (TileBlock) o2;
			return this.tile == tb.getTile();
		}
		return false;
	}
	
}
