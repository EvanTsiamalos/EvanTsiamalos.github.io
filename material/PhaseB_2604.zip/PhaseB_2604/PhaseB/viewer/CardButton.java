package viewer;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import model.card.*;


/**
 * Class that represents the buttons of the character cards. Each one of them is associated with a Character CArd and it is provided with an image icon.
 * @author tem2604
 *
 */
public class CardButton extends JButton {
	private CharacterCard card;
	
	
	/**
	 * <b>Constructor:</b> Takes a caracterCard and associates it with a button. It sets the appropriate image icon, according to the card<br>
	 * <b>Postcondition:</b> Creates a new cardButon with the character card given that has the associated image icon<br>
	 * @param c The Character Card of the button
	 */
	public CardButton(CharacterCard c) {
		this.card=c;
		if (card instanceof ArcheologistCard ) {
			this.setIcon(new ImageIcon("images_editted\\archaeologist60x100.png"));
		}
		else if (card instanceof AssistantCard ) {
			this.setIcon(new ImageIcon("images_editted\\assistant60x100.png"));
		}
		else if (card instanceof DiggerCard ) {
			this.setIcon(new ImageIcon("images_editted\\digger60x100.png"));
		}
		else {
			this.setIcon(new ImageIcon("images_editted\\professor60x100.png"));
		}
		
		this.setToolTipText(card.toString());
	}
	
	/**
	 * <b>Accessor</b><br>
	 * <b>Postcondition:</b> Gives the card associated with the button<br>
	 * 
	 * @return The card associated with the button
	 */
	public CharacterCard getCard() {
		return this.card;
	}
	
	
	/**
	 * <b>Transformer</b><br>
	 * <b>Precondition</b> A character card<br>
	 * <b>Postcondition</b> Sets the character card<br>
	 * 
	 * @param The character card to set
	 */
	public void setCard(CharacterCard c) {
		this.card = c;
		this.setToolTipText(c.toString());
		this.setEnabled(!c.isUsed());
	}
	
	/**
	 * <b>Transformer</b><br> 
	 * <b>Postcondition:</b> If the card is used , it sets the butto as disabled<br>
	 */
	public void updateCardButton() {
		this.setEnabled(!card.isUsed());
	}
}
