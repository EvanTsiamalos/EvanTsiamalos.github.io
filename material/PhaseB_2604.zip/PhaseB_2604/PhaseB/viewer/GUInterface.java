package viewer;
import javax.imageio.ImageIO;
import javax.swing.*;

import controller.Controller;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import model.bag.Bag;
import model.board.Board;
import model.card.*;
import model.player.Player;
import model.tile.*;
import model.tileCollection.TileCollection;


/**
 * Class that implements the Graphic interface of the game. It observes all the actions taken by the players and updates the game through the controller. It also takes all the informartion that it needs from the controller.
 * @author tem2604
 *
 */
public class GUInterface extends JFrame{
	//private JFrame frame;
	private JLabel player, useCharacter;	//  Label for the name of player that plays
	private JButton[] CharacterButtons;  //Burrons for the characterCards
	private JLabel tilesToChoose;
	private JButton pickTiles;  //Button to pick tiles
	private boolean pickTilesFlag;
	private JButton drawTiles;	// Button to draw tiles from the bag and automatically get them in the proper fields
	private boolean drawTilesFlag;
	private JButton endTurn;	// Button to move to the next player
	private boolean endTurnFlag;
	private BorderLayout borderLayout;	// Border layout for the whole frame center for the tbleaux, east and south to be used
	private JLayeredPane tableaux;	// the area of the tableaux it will contain five panels 
	private JPanel boardPanel;
	private JPanel tilesChosen;  // Area that shows the tiles the player has chosen
	private JPanel sidePanel;		// The panel that displays all the options
	private JPanel lowerPanel;		// the panel that displays all the tiles the player has collected so far
	
	
	private boolean chooseTileFlag;
	private JPanel up,mid,low;
	
	private JPanel skeletonPanel;  //panels for the tile areas on the board 
	private JPanel amphoraPanel;
	private JPanel rockPanel;
	private JPanel mosaicPanel;
	private JPanel statuePanel;
	private final TileBlock[] tileBLocks;
	private Controller controller;
	private CardButton archButton;
	private CardButton assistButton;
	private CardButton diggerButton;
	private CardButton profButton ;
	private boolean cardButtonFlag;
	private JFrame nf,ef,sf,wf;
	private JPanel nfpanel,efpanel,sfpanel,wfpanel;
	
	private ArrayList<TileBlock> amphoreasTileBlocks;
	private ArrayList<TileBlock> skeletonTileBlocks;
	private ArrayList<TileBlock> mosaicTileBlocks;
	private ArrayList<TileBlock> statueTileBlocks;
	private ArrayList<TileBlock> rockTileBlocks;
	
	
	private JFrame tilesChoosenFrame;
	private JPanel buttonPanel;
	private JPanel tilesChoosenPanel;
	
	private boolean doneFlag;
	
	
	/**
	 * <b>Constructor</b>
	 * <b>Postcondition:</b> Creates a new window to start the game
	 */
	public GUInterface() {
		this.drawTilesFlag = true;
		this.amphoreasTileBlocks = new ArrayList<>();
		this.skeletonTileBlocks = new ArrayList<>();
		this.mosaicTileBlocks = new ArrayList<>();
		this.statueTileBlocks = new ArrayList<>();
		this.rockTileBlocks = new ArrayList<>();
		this.controller = new Controller();						//Initialize controller
		this.controller.initGame();
		this.controller.setAreaPlayed(-1);
		this.controller.setCardWasPlayed(false);
		
		this.tileBLocks = new TileBlock[27+24+24+30+30];
	
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		this.setResizable(false);
		
		this.setSize(900, 800);
		initializeComponents();
		
		this.tilesChoosenFrame = new JFrame();
		this.tilesChoosenFrame.setBounds(1030, 550, 200, 200);
		this.tilesChoosenFrame.setSize(200,200);
		this.tilesChoosenFrame.setResizable(false);
		this.tilesChoosenFrame.setLayout(new BorderLayout());
		
		this.tilesChoosenPanel = new JPanel();
		this.tilesChoosenPanel.setLayout(new FlowLayout());
		this.tilesChoosenPanel.setBounds(0, 0, 200, 100);
		
		
		this.buttonPanel = new JPanel();
		this.buttonPanel.setLayout(new GridLayout(2,0));
		JButton ready = new JButton("DONE");
		JButton remove = new JButton("Remove Tiles");
		remove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TileBlock t;
				Tile tile;
				
				for (int i = 0; i < tilesChoosenPanel.getComponentCount(); i++) {
					t = (TileBlock) tilesChoosenPanel.getComponent(i);
					tile = t.getTile();
					controller.removeChosenTile(tile);
					tileBlockAdder(tile);
					
				}
				
				controller.setAreaPlayed(-1);
				
				amphoraPanel.validate();
				amphoraPanel.repaint();
				skeletonPanel.validate();
				skeletonPanel.repaint();
				mosaicPanel.validate();
				mosaicPanel.repaint();
				statuePanel.validate();
				statuePanel.repaint();

				
				tilesChoosenPanel.removeAll();
				tilesChoosenPanel.validate();
				tilesChoosenPanel.repaint();
				
				pickTilesFlag = false;
				
				if (controller.getCardWasPlayed() && controller.getCardUsed() instanceof ProfessorCard) {
					controller.setAllowedAreas("");
					String newAllowedAreas = "";
					for (int i = 0; i < 4; i++) {
						if (! (i == controller.getAreaPlayed())) newAllowedAreas += i;
					}
					
					controller.setAllowedAreas(newAllowedAreas);
					
					
				}
			}
			
		});
		ready.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				if (doneFlag) {	
					pickTilesFlag = true;
					tilesChoosenFrame.setVisible(false);
				}
				
			}
		});
		
		this.buttonPanel.add(remove);
		this.buttonPanel.add(ready);
		this.tilesChoosenFrame.add("South",this.buttonPanel);
		this.tilesChoosenFrame.add("Center",this.tilesChoosenPanel);
	}

	/**
	 * <b>Transformer</b>
	 * <b>Postcondition</b> Initiallize all the componenets of the game
	 */
	private void initializeComponents() {
		this.nf = new JFrame("North");
		this.sf = new JFrame("South");
		this.wf = new JFrame("West");
		this.ef = new JFrame("East");
		
		sf.setBounds(920, 50, 200, 200);
		sfpanel = new JPanel();
		sfpanel.setLayout(new FlowLayout());
		sf.add(sfpanel);
		sf.setVisible(true);
		ef.setBounds(920,300, 200, 200);
		efpanel = new JPanel();
		efpanel.setLayout(new FlowLayout());
		ef.add(efpanel);
		ef.setVisible(true);
		nf.setBounds(1130, 50, 200, 200);
		nfpanel = new JPanel();
		nfpanel.setLayout(new FlowLayout());
		nf.add(nfpanel);
		nf.setVisible(true);
		wf.setBounds(1130, 300, 200, 200);
		wfpanel = new JPanel();
		wfpanel.setLayout(new FlowLayout());
		wf.add(wfpanel);
		wf.setVisible(true);
		this.setLayout(new BorderLayout());
		this.sidePanel = new JPanel();
		this.sidePanel.setBackground(Color.LIGHT_GRAY);
		this.sidePanel.setPreferredSize(new Dimension(200,100));
		this.lowerPanel = new JPanel();
		this.lowerPanel.setBackground(Color.lightGray);
		this.lowerPanel.setLayout(new FlowLayout());
		this.lowerPanel.setPreferredSize(new Dimension(50,100));
		this.boardPanel = new JPanel();
		boardPanel.setBackground(Color.LIGHT_GRAY);
		boardPanel.setSize(700, 700);
		ImageIcon boardIcon = new ImageIcon("images_2020\\background3.png");
		JLabel backGround = new JLabel();
		backGround.setIcon(boardIcon);
		boardPanel.add("Center",backGround);
		boardPanel.add(backGround);
		this.tableaux = new JLayeredPane();
		this.tableaux.setBackground(Color.LIGHT_GRAY);
		this.tableaux.setPreferredSize(new Dimension(700,700));
		this.tableaux.add(boardPanel,JLayeredPane.DEFAULT_LAYER);
		sidePanel.setLayout(new BorderLayout());
		this.up = new JPanel();
		up.setOpaque(false);
		this.mid=new JPanel();
		this.low = new JPanel();
		int plaPos = this.controller.getPositionPlaying();
		String name = this.controller.getPlayer(plaPos).getName();
		this.player = new JLabel(name,SwingConstants.CENTER);
		player.setFont(new Font("Arial",Font.BOLD,25));
		this.useCharacter = new JLabel("Use Character",SwingConstants.CENTER);
		up.setLayout(new GridLayout(2,0,1,100));
		up.add(this.player);
		up.add(useCharacter);
		sidePanel.add("North",this.up);
		
		
		
		this.mid = new JPanel();
		mid.setOpaque(false);
		mid.setLayout(new GridLayout(2,2,20,20));
		
		
		this.archButton = new CardButton(controller.getplayerCard(new ArcheologistCard()));
		this.assistButton = new CardButton(controller.getplayerCard(new AssistantCard()));
		this.diggerButton = new CardButton(controller.getplayerCard(new DiggerCard()));
		this.profButton = new CardButton(controller.getplayerCard(new ProfessorCard()));
		
	
		
		archButton.setOpaque(true);
	
		assistButton.setSize(60,100);
	
		diggerButton.setSize(60,100);

		profButton.setSize(60,100);
		
		
		this.archButton.addActionListener(new CardListener());
		this.assistButton.addActionListener(new CardListener());
		this.diggerButton.addActionListener(new CardListener());
		this.profButton.addActionListener(new CardListener());
		mid.add(this.archButton);
		mid.add(assistButton);
		mid.add(diggerButton);
		mid.add(profButton);
		mid.repaint();
		
		sidePanel.add("Center",mid);
	
		
		
		
		
		this.low = new JPanel();
		low.setOpaque(false);
		low.setLayout(new GridLayout(3,0));
		
		this.drawTiles = new JButton("Draw Tiles");
		this.drawTiles.setToolTipText("Draw 4 tiles from the bag and put them on the board");
		this.drawTiles.addActionListener(new DrawTilesListener());
		
		this.endTurn = new JButton("End Turn");
		endTurn.addActionListener(new EndTurnListener());
		
		this.pickTiles = new JButton("Pick Tiles");
		this.pickTiles.setToolTipText("Take the chosen tiles");
		this.pickTiles.addActionListener(new PickTilesListener());
		low.add(this.drawTiles);
		low.add(this.pickTiles);
		low.add(this.endTurn);
		
		
		sidePanel.add("South",low);
		
		

		
		
		Board b = controller.getBoard();
		
		
		this.mosaicPanel = new JPanel();
		
		this.mosaicPanel.setOpaque(false);
		this.mosaicPanel.setBounds(45, 22, 190, 190);
		this.mosaicPanel.setLayout(new FlowLayout());

		

		this.statuePanel = new JPanel();
		this.statuePanel.setOpaque(false);
		this.statuePanel.setBounds(465, 22, 190, 190);
		this.statuePanel.setLayout(new FlowLayout());
		
		

		
		
		this.amphoraPanel = new JPanel();
		this.amphoraPanel.setOpaque(false);
		this.amphoraPanel.setBounds(45, 447, 190, 190);
		this.amphoraPanel.setLayout(new FlowLayout());

		
		
		this.skeletonPanel = new JPanel();
		this.skeletonPanel.setOpaque(false);
		this.skeletonPanel.setBounds(467, 447, 190, 190);
		this.skeletonPanel.setLayout(new FlowLayout());
		
		
		
		
		this.rockPanel = new JPanel();
		this.rockPanel.setOpaque(false);
		this.rockPanel.setBounds(255,287,190,190);
		this.rockPanel.setLayout(new FlowLayout());
		

		
		
		tileBlockDistributor();
		
		
		
		this.tableaux.add(statuePanel,JLayeredPane.DRAG_LAYER);
		this.tableaux.add(amphoraPanel,JLayeredPane.DRAG_LAYER);
		this.tableaux.add(skeletonPanel,JLayeredPane.DRAG_LAYER);
		this.tableaux.add(rockPanel,JLayeredPane.DRAG_LAYER);
		this.tableaux.add(mosaicPanel,JLayeredPane.DRAG_LAYER);

		
		playerTileDistributor();
		
		

		this.getContentPane().add("Center",this.sidePanel);
		this.getContentPane().add("South",this.lowerPanel);
		
		this.getContentPane().add("West",this.tableaux);
		this.setVisible(true);
		

	}
	
	/*
	 * Updates the lower panel with the tiles of the player playing
	 */
	private void playerTileDistributor() {
		lowerPanel.removeAll();
		int posPlaying = this.controller.getPositionPlaying();
		TileCollection col;
		Player p = controller.getPlayer(posPlaying);
		col = p.getAllTiles();
		for (int i=0; i < col.size(); i++) {
			this.lowerPanel.add(new TileBlock(col.getTile(i)));
		}
		
		lowerPanel.validate();
		lowerPanel.repaint();
	}
	
	
	/*
	 * Updates the panels of the board, the tile areas
	 */
	private void tileBlockDistributor() {
		this.amphoraPanel.removeAll();
		this.skeletonPanel.removeAll();
		this.statuePanel.removeAll();
		this.mosaicPanel.removeAll();
		this.rockPanel.removeAll();
		
		TileCollection coll = this.controller.getAllBoardTiles();
		for (int i = 0; i < coll.size(); i++) {
			tileBlockAdder(coll.getTile(i));
		}
		
		
		amphoraPanel.validate();
		amphoraPanel.repaint();
		skeletonPanel.validate();
		skeletonPanel.repaint();
		mosaicPanel.validate();
		mosaicPanel.repaint();
		statuePanel.validate();
		statuePanel.repaint();
		rockPanel.validate();
		rockPanel.repaint();
		
	}
	
	/*
	 * Addsa tile block on the board panels
	 */
	private void tileBlockAdder(Tile tile) {

		TileBlock tileBlock = new TileBlock(tile);
		int area = tileBlock.getArea();
		if (area != 4) tileBlock.addMouseListener(new TileBlockListener());
		if (area == 0) this.skeletonPanel.add(tileBlock);
		else if (area == 1) this.statuePanel.add(tileBlock);
		else if (area == 2) this.mosaicPanel.add(tileBlock);
		else if (area == 3) this.amphoraPanel.add(tileBlock);
		else if (area == 4) this.rockPanel.add(tileBlock);
	
		
		
		
	}
	
	/*
	 * Update the frames of the players
	 */
	private void playerTilePanelsUpdate() {
		sfpanel.removeAll();
		wfpanel.removeAll();
		nfpanel.removeAll();
		efpanel.removeAll();
		for (int i =0; i < controller.getPlayer(0).getAllTiles().size(); i++) {
			this.sfpanel.add(new TileBlock(controller.getPlayer(0).getAllTiles().getTile(i)));
		}
		
		this.sfpanel.validate();
		this.sfpanel.repaint();
		
		
		for (int i =0; i < controller.getPlayer(1).getAllTiles().size(); i++) {
			this.efpanel.add(new TileBlock(controller.getPlayer(1).getAllTiles().getTile(i)));
		}
		
		this.efpanel.validate();
		this.efpanel.repaint();
		for (int i =0; i < controller.getPlayer(2).getAllTiles().size(); i++) {
			this.nfpanel.add(new TileBlock(controller.getPlayer(2).getAllTiles().getTile(i)));
		}
		
		this.nfpanel.validate();
		this.nfpanel.repaint();
		for (int i =0; i < controller.getPlayer(3).getAllTiles().size(); i++) {
			this.wfpanel.add(new TileBlock(controller.getPlayer(3).getAllTiles().getTile(i)));
		}
		
		this.wfpanel.validate();
		this.wfpanel.repaint();
	}
	/**
	 * <b>Postcondition:</b> Announce the winner
	 */
	public void endGame() {
		
		String ann = controller.endGame();		
		JOptionPane.showMessageDialog(null,ann,"End game information",JOptionPane.INFORMATION_MESSAGE);
		System.exit(EXIT_ON_CLOSE);
	}
	
	
	
	/*
	 * Updates the buttons
	 */
	private void updateButtons() {
		
		this.archButton.setCard(controller.getplayerCard(new ArcheologistCard()));
		this.assistButton.setCard(controller.getplayerCard(new AssistantCard()));
		this.diggerButton.setCard(controller.getplayerCard(new DiggerCard()));
		this.profButton.setCard(controller.getplayerCard(new ProfessorCard()));
		
		this.mid.validate();
		this.mid.repaint();
		
		this.sidePanel.validate();
		this.sidePanel.repaint();
	}
	/**
	 * Class responsible for the action of choosing a tile from the board.<br> It is mostly going to be used by TileBlocks that are going to possess a MouseListener
	 * @author tem2604
	 *
	 */
	
	private class TileBlockListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			
			tilesChoosenFrame.setVisible(true);
			if (chooseTileFlag) {	
				if (!controller.getCardWasPlayed()) {	
					TileBlock comp = (TileBlock) e.getSource();
					TileBlock chosenTile = new TileBlock(comp.getTile());
					int area = comp.getArea();
					if (controller.getAreaPlayed() == -1){
						
						controller.setAreaPlayed(area);
						
						controller.chooseTile(comp.getTile());
						
						
						tilesChoosenPanel.add(chosenTile);
						
						if (area == 0) skeletonPanel.remove(comp);
						else if (area == 1) statuePanel.remove(comp);
						else if (area == 2) mosaicPanel.remove(comp);
						else if (area == 3) amphoraPanel.remove(comp);
						
						amphoraPanel.validate();
						amphoraPanel.repaint();
						skeletonPanel.validate();
						skeletonPanel.repaint();
						mosaicPanel.validate();
						mosaicPanel.repaint();
						statuePanel.validate();
						statuePanel.repaint();
						
						tilesChoosenPanel.validate();
						tilesChoosenPanel.repaint();
						tilesChoosenFrame.setVisible(true);
					}
					else {
						if ( controller.getTileRemoveLimit() > controller.getTilesChosen().size()) {
							if (area == controller.getAreaPlayed()) {
								controller.chooseTile(comp.getTile());
								tilesChoosenPanel.add(chosenTile);
								
								if (area == 0) skeletonPanel.remove(comp);
								else if (area == 1) statuePanel.remove(comp);
								else if (area == 2) mosaicPanel.remove(comp);
								else if (area == 3) amphoraPanel.remove(comp);
								
								amphoraPanel.validate();
								amphoraPanel.repaint();
								skeletonPanel.validate();
								skeletonPanel.repaint();
								mosaicPanel.validate();
								mosaicPanel.repaint();
								statuePanel.validate();
								statuePanel.repaint();
								
								tilesChoosenPanel.validate();
								tilesChoosenPanel.repaint();
								tilesChoosenFrame.setVisible(true);
							}
							else {
								System.out.println("Trying to take tiles from wrong area");
							}
						}
						
					}
				}
				else {
					TileBlock comp = (TileBlock) e.getSource();
					TileBlock chosenTile = new TileBlock(comp.getTile());
					int area = comp.getArea();
					String areaString = String.valueOf(area);
					if ( controller.getTileRemoveLimit() > controller.getTilesChosen().size()) {
						if (! (controller.getCardUsed() instanceof ProfessorCard)) {
							if (controller.getAllowedAreas().indexOf(areaString) >=0) {
								controller.chooseTile(comp.getTile());
								tilesChoosenPanel.add(chosenTile);
								if (area == 0) skeletonPanel.remove(comp);
								else if (area == 1) statuePanel.remove(comp);
								else if (area == 2) mosaicPanel.remove(comp);
								else if (area == 3) amphoraPanel.remove(comp);
								
								amphoraPanel.validate();
								amphoraPanel.repaint();
								skeletonPanel.validate();
								skeletonPanel.repaint();
								mosaicPanel.validate();
								mosaicPanel.repaint();
								statuePanel.validate();
								statuePanel.repaint();
								
								tilesChoosenPanel.validate();
								tilesChoosenPanel.repaint();
								tilesChoosenFrame.setVisible(true);
							}
						}
						else {
							if (controller.getAllowedAreas().indexOf(areaString) >=0) {
								String alArOld = controller.getAllowedAreas();
								String alArNew = "";
								for (int i = 0; i < alArOld.length() ; i++) {
									if (! Character.toString(alArOld.charAt(i)).equals(areaString)){
										alArNew += Character.toString(alArOld.charAt(i));
									}
									
								}
								controller.setAllowedAreas(alArNew);
								controller.chooseTile(comp.getTile());
								tilesChoosenPanel.add(chosenTile);
								if (area == 0) skeletonPanel.remove(comp);
								else if (area == 1) statuePanel.remove(comp);
								else if (area == 2) mosaicPanel.remove(comp);
								else if (area == 3) amphoraPanel.remove(comp);
								
								amphoraPanel.validate();
								amphoraPanel.repaint();
								skeletonPanel.validate();
								skeletonPanel.repaint();
								mosaicPanel.validate();
								mosaicPanel.repaint();
								statuePanel.validate();
								statuePanel.repaint();
								
								tilesChoosenPanel.validate();
								tilesChoosenPanel.repaint();
								tilesChoosenFrame.setVisible(true);
							}
						}
					}
					
				}
			}	
			else {
				System.out.println("Cannot choose tiles yet. Must Draw Tiles or wait for the next turn");
			}
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		

		
		
	}
	/**
	 * Class responsible for the actions on the Card Buttons
	 * @author tem2604
	 *
	 */
	private class CardListener implements ActionListener {

		/**
		 * <b>Transformer</b>
		 * <b>Postcondition</b> Performs the actions when pushing the button of a card to use
		 */
		public void actionPerformed(ActionEvent e) {
			CardButton b = (CardButton) e.getSource();
			if (cardButtonFlag && ! controller.getCardWasPlayed()) {
				controller.useCard(b.getCard());
				b.setEnabled(false);
				System.out.println("Button pressed: " + b.getCard().toString() );
				
				
				chooseTileFlag = true;
				doneFlag = true;
				
			}
			else System.out.println("Cannot use Card because " + (cardButtonFlag ? "It is not time " : "you have already used a card")  );
			
		}
	}
	
	/**
	 * Class responsible for the actions on the pisckTile Button
	 * @author tem2604
	 *
	 */
	private class PickTilesListener implements ActionListener{
		
		/**
		 * <b>Transformer</b>
		 * <b>Postcondition</b> Performs the actions when pushing the button pickTiles
		 */
		public void actionPerformed(ActionEvent e) {
			if (pickTilesFlag) {	
				controller.pickTiles();
				
				tileBlockDistributor();
				
				tilesChoosenPanel.removeAll();
				tilesChoosenPanel.validate();
				tilesChoosenPanel.repaint();
				
				playerTileDistributor();
				pickTilesFlag = false;
				doneFlag = false;
				endTurnFlag = true;
				cardButtonFlag = true;
			}
			else System.out.println("Cannot pick tiles");
			
		}
		
	}
	
	/**
	 * Class responsible for the actions of the button endTurn
	 * @author tem2604
	 *
	 */
	private class EndTurnListener implements ActionListener{
		
		/**
		 * <b>Transformer</b>
		 * <b>Postcondition</b> Performs the actions when pushing the button endTurn
		 */
		public void actionPerformed(ActionEvent e) {
			if (endTurnFlag) {	
				controller.endTurn();
				
				int plaPos = controller.getPositionPlaying();
				String name = controller.getPlayer(plaPos).getName();
				playerTileDistributor();
				player.setText(name);
				
				
				drawTilesFlag=true;
				pickTilesFlag = false;
				endTurnFlag = false;
				chooseTileFlag = false;
				doneFlag = false;
				
				updateButtons();
				playerTilePanelsUpdate();
				cardButtonFlag = false;
			}else System.out.println("Cannot end turn");
		}
		
	}
	
	/**
	 * Class responsible for the actions of the button drawTiles
	 * @author tem2604
	 *
	 */
	private class DrawTilesListener implements ActionListener{
		/**
		 * <b>Transformer</b>
		 * <b>Postcondition</b> Performs the actions when pushing the button drawTiles
		 */
		public void actionPerformed(ActionEvent e) {
			if (drawTilesFlag ) {
				
				GUInterface.this.controller.drawTiles();
				GUInterface.this.tileBlockDistributor();
				
				GUInterface.this.amphoraPanel.validate();
				GUInterface.this.amphoraPanel.repaint();
				GUInterface.this.skeletonPanel.validate();
				GUInterface.this.skeletonPanel.repaint();
				GUInterface.this.mosaicPanel.validate();
				GUInterface.this.mosaicPanel.repaint();
				GUInterface.this.statuePanel.validate();
				GUInterface.this.statuePanel.repaint();
				GUInterface.this.rockPanel.validate();
				GUInterface.this.rockPanel.repaint();
				
				drawTilesFlag = false;
				chooseTileFlag = true;
				doneFlag = true;
				if (controller.isGameEnded()) {
					chooseTileFlag = false;
					doneFlag = false;
					endTurnFlag = false;
					
					endGame();
				}
			}
			else System.out.println("Already drawn tiles"); 
		}
		
	}
}



