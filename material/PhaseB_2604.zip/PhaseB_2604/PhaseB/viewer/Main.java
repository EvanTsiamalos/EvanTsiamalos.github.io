package viewer;

public class Main {
	public static void main(String[] args) {
		GUInterface gui = new GUInterface();
	}
}
