package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Random;

import org.junit.Test;

import controller.Controller;
import junit.framework.TestCase;
import model.bag.*;
import model.board.Board;
import model.player.Player;
import model.tile.AmphoreasColour;
import model.tile.AmphoreasTile;
import model.tile.FindingTile;
import model.tile.MosaicColour;
import model.tile.Tile;
import model.tileCollection.TileCollection;
import model.tile.*;

public class testGame extends TestCase {

	public void testInitiallization() {
		Controller controller = new Controller();
		
		Bag bag = controller.getBag();
		assertEquals(bag.isEmpty(), true);
		
		Board board = controller.getBoard();
		
		controller.initGame();
		
		bag = controller.getBag();
		assertEquals(bag.isEmpty(), false);
		int maxSize = bag.getTiles().size();
		assertEquals(controller.getCardWasPlayed(),false);
		int i = controller.getPositionPlaying();
		assertEquals(i == 0 || i == 1 || i ==2 || i==3, true);
		assertEquals(controller.getTileRemoveLimit() == 2, true);
		int j = bag.getTiles().size();
		assertEquals( j == maxSize , true );
		System.out.println(bag.getTiles().size());
		System.out.println(27+24+24+30+30);
		
		assertEquals(controller.getTilesChosen().size(),0);
		assertEquals(controller.getAreaPlayed(),0);
		
		for (int k = 0 ; k < 10; k ++) {
			controller.drawTiles();
		}
		assertEquals(maxSize - (10)*4, controller.getBag().getTiles().size());
		
	}
	
	
	public void testPickTiles() {
		Random random = new Random();
		Controller controller = new Controller();
		controller.initGame();
		Player p = controller.getPlayer(controller.getPositionPlaying());
		int initPlayerSize = p.getAllTiles().size();
		controller.drawTiles();
		int area = random.nextInt(4);
		controller.setAreaPlayed(area);
		Board board = controller.getBoard();
		int initBoardSize = controller.getAllBoardTiles().size();
		TileCollection col = (area == 0) ? board.getSkeletonArea() : ((area == 1) ? board.getStatueArea() : ((area == 2) ? board.getAmphoreasArea() : board.getMosaicArea()));
		while (col.size() == 0) {
			controller.drawTiles();
			col = (area == 0) ? board.getSkeletonArea() : ((area == 1) ? board.getStatueArea() : ((area == 2) ? board.getAmphoreasArea() : board.getMosaicArea()));
		}
		int j = 0;
		Tile tile;
		while (j <controller.getTileRemoveLimit()  && col.size()-(j+1)>0) {
			controller.chooseTile(col.getTile(j));
			j++;
		}
		
		assertEquals(controller.getTilesChosen().size(),j);
		controller.pickTiles();
		
		
		
		p = controller.getPlayer(controller.getPositionPlaying());
		assertEquals(p.getAllTiles().size(),initPlayerSize  + j);

		
		
		
	 
	}

	public void testEndTurn() {
		Random random = new Random();
		
		Controller controller = new Controller();
		Board board = controller.getBoard();
		controller.initGame();
		Player p = controller.getPlayer(controller.getPositionPlaying());
		int positionPlaying = controller.getPositionPlaying();
		for (int i = 0 ; i < 10 ; i ++) controller.drawTiles();
		
		int area = random.nextInt(4);
		TileCollection col = (area == 0) ? board.getSkeletonArea() : ((area == 1) ? board.getStatueArea() : ((area == 2) ? board.getAmphoreasArea() : board.getMosaicArea()));
		controller.endTurn();
		assertEquals(controller.getCardWasPlayed(), false);
		assertEquals(controller.getAreaPlayed(), -1);
		assertEquals(controller.getPositionPlaying(), (positionPlaying + 1)%4);
		
		
	}
	
	public void testGameSteps() {
		Random random = new Random();
		
		Controller controller = new Controller();
		Board board = controller.getBoard();
		controller.initGame();
		int area;
		Player p;
		int i = 0;
		TileCollection col;
		while (i < 17 && !controller.isGameEnded()) {
			p = controller.getPlayer(controller.getPositionPlaying());
			
			int initPlayerSize = p.getAllTiles().size();
			controller.drawTiles();
			area = random.nextInt(4);
			controller.setAreaPlayed(area);
			board = controller.getBoard();
			int initBoardSize = controller.getAllBoardTiles().size();
			col = (area == 0) ? board.getSkeletonArea() : ((area == 1) ? board.getStatueArea() : ((area == 2) ? board.getAmphoreasArea() : board.getMosaicArea()));
			while (col.size() == 0) {
				area = (area + 1)%4;
				col = (area == 0) ? board.getSkeletonArea() : ((area == 1) ? board.getStatueArea() : ((area == 2) ? board.getAmphoreasArea() : board.getMosaicArea()));
			}
			
			int j = 0;
			while (j <controller.getTileRemoveLimit()  && col.size()-(j+1)>=0) {
				controller.chooseTile(col.getTile(j));
				j++;
			}
			System.out.println(i + " " + p.getName() + " " + ((area == 0) ? "Skeleton area" : ((area == 1) ? "Statue Area" : ((area == 2) ? "Amphora area" : "Mosaic Area"))) + " " + j);
			assertEquals(controller.getTilesChosen().size(),j);
			controller.pickTiles();
			
			
			
			p = controller.getPlayer(controller.getPositionPlaying());
			assertEquals(p.getAllTiles().size(),initPlayerSize  + j);
			assertEquals(controller.getAllBoardTiles().size(), initBoardSize - j);
			
			controller.endTurn();
			if (controller.isGameEnded()) {
				assertEquals(board.getRockArea().size() , 16);
				
			}
			i++;
		} 
		
	}
	
	
	
	public void testCountPoints() {
		Player p = new Player("TestPlayer",0);
		Tile tile;
		ArrayList<Tile> tiles = new ArrayList<>();
		for (int i = 0 ; i < 9 ; i ++) {
			tile =new AmphoreasTile(AmphoreasColour.values()[i%6]);
			p.takeTile((FindingTile)tile);
			

			
		}p.setMostStatue("KARYATIDA", 0);
		p.setMostStatue("SPHINX", 0);
		
		p.countPoints();
		assertEquals(p.getPoints(),6);
	
		p = new Player("TestPlayer",0);
		for (int i = 0 ; i <10 ; i ++) {
			if (i < 4) {tile = new MosaicTile(MosaicColour.values()[0]); p.takeTile((FindingTile) tile);}
			else if (i >= 4 && i <8) {
				tile = new MosaicTile(MosaicColour.values()[i%3]);
				p.takeTile((FindingTile) tile);
			}
			else {
				tile = new MosaicTile(MosaicColour.values()[2]);
				p.takeTile((FindingTile) tile);
			}
		}
		
		p.setMostStatue("KARYATIDA", 0);
		p.setMostStatue("SPHINX", 0);
		
		p.countPoints();
		System.out.println(p.getPoints());
		assertEquals(p.getPoints(),10);
	
		p = new Player("TestPlayer",0);
		
		for (int i = 0 ; i  < 3 ; i ++) {
			p.takeTile(new SkeletonTile(1,0));
			p.takeTile(new SkeletonTile(1,1));
			if (i == 1) {
				p.takeTile(new SkeletonTile(0,0));
				p.takeTile(new SkeletonTile(0,1));
			}
			
		}
		
		p.takeTile(new SkeletonTile(1,0));
		p.takeTile(new SkeletonTile(0,1));
		p.countPoints();
		assertEquals(p.getPoints(),7);
	
	}
	
	
	
		
	
}
