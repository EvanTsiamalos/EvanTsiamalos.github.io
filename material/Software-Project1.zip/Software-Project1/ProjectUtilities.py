#Παναγιώτης Δούλης, 1822
#Ευάγγελος Τσιάμαλος, 2604


import numpy as np

class Utilities:


    def logistic(x, discrete = False): 
        if not discrete:
            return 1/(1 + np.exp(-x))
        else:
            return 0 if 1/(1 + np.exp(-x)) < 0 else 1.0

    def relu(x):
        if len(x.shape) == 1:
            res = np.zeros(x.size)
            for i in range(x.size):
                res[i] = x[i] if x[i] >=0 else 0.0
            return res 
        else:
            res = np.zeros(x.shape)
            for i in range(x.shape[0]):
                for j in range(x.shape[1]):
                    res[i,j] = x[i,j] if x[i,j] >=0 else 0.0
            return res
    def tanh(x): return (np.exp(x) - np.exp(-x))/(np.exp(x) + np.exp(-x)) 
    

    '''

    def softmax(x):
        
        #x: an 1d array or a matrix with multiple arrays in rows

        
        if len(x.shape) == 1:
            exp_array = np.exp(x)
            s = np.sum(exp_array)
            return exp_array/s 
        elif len(x.shape) == 2:
            exp_array = np.exp(x) 
            s = exp_array.sum(axis = 1)
            return (exp_array.T / s).T   

    '''

    def logistic_derivative(x):
        s =  1/(1 + np.exp(-x))
        return s*(1 - s)
    def tahn_derivative(x):
        return 1 - (np.exp(x) - np.exp(-x))/(np.exp(x) + np.exp(-x)) 

    def relu_derivative(x):
        if len(x.shape) == 1:
            res = np.zeros(x.size)
            for i in range(x.size):
                res[i] = 1.0 if x[i] >=0 else 0.0
            return res 
        else:
            res = np.zeros(x.shape)
            for i in range(x.shape[0]):
                for j in range(x.shape[1]):
                    res[i,j] = 1.0 if x[i,j] >=0 else 0.0
            return res


    def entropyError(y_hat,y):
        return -np.sum(y * np.log(1e-10 + y_hat))/y.size

    
    def simpleMovingAverage(y,k):
        # calculate simpple mean average for k days
        # y: np.array that contains the time series
        # k: integer; number of days to apply the filter
        # precondition: size of y > k
        # returns np.array with NaN in the first k-1 indexes containing the smoothed time series
        # The size of the array returned is of the SAME size as y: y.size = simpleMovingAverage(y,K).size
        n = y.size
        x = np.zeros(n)
        for l in range(k):
            x[l] = np.nan
        for i in range(k-1,n):
            s = sum(y[i-k+1:i+1])
            x[i] = s/k
        return x[k:]#,y[k:]

    def weightedMovingAverage(y,k):
        #calculate the weighted moving average, bias at the most recent events
        # y: np.array that contains the time series
        # k: integer; number of days to apply the filter
        # precondition: size of y > k
        # returns np.array with NaN in the first k-1 indexes containing the smoothed time series
        # The size of the array returned is of the SAME size as y: y.size = weightedMovingAverage(y,K).size
        n = y.size
        x = np.zeros(n)
        for l in range(k):
            x[l] = np.nan
        filt = np.arange(1,k+1)/k
        ss = sum(filt)
        for i in range(k-1,n):
            x[i] = sum((y[i-k+1:i+1]*filt))/ss
        return x[k:],y[k:]        

    def expMovingAverage(y,k):
        #calculate the exponential smoother of order k
        # y: np.array that contains the time series
        # k: integer; number of days to apply the filter
        # precondition: size of y > k
        # returns np.array with NaN in the first k indexes containing the smoothed time series
        # The size of the array returned is of the SAME size as y: y.size = expMovingAverage(y,K).size
        n =y.size
        x = simpleMovingAverage(y,k)
        multiplier = 2/(k+1)
        z = np.zeros(n)
        for l in range(k):
            z[l] = np.nan
        z[k-1] = x[k-1]
        for i in range(k,n):
            z[i] = y[i]*multiplier +x[i-1]*(1-multiplier)
        return z

    def readData(filename,start, end):
        '''
        Reads a file containing the time series of the data 
    
        '''
        with open(filename , "r") as fh:
            L = fh.readlines()
        L = list(map(lambda x : float(x.strip())))
        y = np.array(L)
        return y[start:end]

    def formatData(Y,k,addUnit =False):

        '''
        Prepares the data of the time-series for training. It takes a time series Y and returns the X training and y training
        '''
        X = np.empty((Y.size - k,k))
        y = np.empty(Y.size - k)
        for i in range(k,Y.size):
            X[i-k,:] = Y[i - k:i]
            y[i-k] = Y[i]
        return (X, y) if not addUnit else (np.c_[np.ones(X.shape[0]),X], y)
    

