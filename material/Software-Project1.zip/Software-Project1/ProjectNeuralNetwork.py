#Παναγιώτης Δούλης, 1822
#Ευάγγελος Τσιάμαλος, 2604

import numpy as np
import random
from ProjectUtilities import Utilities




class MyNeuralNetwork:

    ## Attributes
    utilities = Utilities()
    W1 = None
    W2 = None
    W3 = None
    b1 = None
    b2 = None
    b3 = None 
    A1 = None 
    A2 = None 
    Z1 = None
    Z2 = None 
    error_record = []
    allLayerNodes = []
    ### Activation functions 
    act_functions = {"logistic": Utilities.logistic, "tanh": Utilities.tanh, "relu":Utilities.relu}
    
    
    ### Activation function derivatives 
    
    derivatives = {"logistic": Utilities.logistic_derivative, "tanh": Utilities.tahn_derivative, "relu":Utilities.relu_derivative}    
    ## Loss functions
    def squaredLoss(self,X,y,total = True):
        ## X is not transpopsed
        
        return np.sum((self.predict(X) - y)**2)/(2*y.size) if total else self.predict(X) - y ## this is for the back propagation algorithm
        


    ## Parameter functions and constructor
    def read_txt(self,filename, readData = True):
        '''
        Static function that reads the parameters of the model from a txt file
        String filename: The name of the file to take the parameters from. CAUTION it needs to be i the same directory as the program
        boolean readData: Provide the training data or not
        
        The data is supposed to be in the format:  
        data filename
        number of inputs    
        number of hidden layers
        .
        .numbers of nodes in hidden layers 
        . 
        activasion
        classifier
        alpha 
        tol 
        maxiters
        verbose
        maxiterstop


        returns the data X_training, y_training
        '''

        with open(filename,"r",encoding="utf-8") as fh:
            if readData: inputFile = fh.readline().strip()
            self.numberOfInputs =  int(fh.readline().strip())   
            self.numberOfLayers = int(fh.readline().strip())
            self.hiddenLayerNodes = []
            for i in range(self.numberOfLayers):
                self.hiddenLayerNodes.append(int(fh.readline().strip()))
            self.activationFunction =  self.act_functions[fh.readline().strip()]
     ## Add the derivative
            self.classifier = bool(fh.readline().strip())
            self.alpha = float(fh.readline().strip())
            self.tol = float(fh.readline().strip())
            self.max_iters = int(fh.readline().strip())
            self.verbose = bool(fh.readline().strip())
            self.max_iter_stop = int(fh.readline().strip())
            print(self)
        if readData:
            with open(inputFile,"r",encoding="utf-8" ) as fh:
                L = fh.readlines()
            L = list(map(lambda x: x.strip().split(),L))
            X = []
            y = []
            for i in L:
                X.append(float(i[:len(i) - 1]))
                y.append(float(i[-1]))
            return X,y 
        else: return None
        

    def __init__(self, numberOfInputs, hiddenLayerNodes = [100],activation = "logistic",classifier = False, alpha = 0.0001, tol = 1e-2, max_epochs = 200 , verbose = True, max_iter_stop = 20 ):
        '''
        Constructor: Constructs the neural network given parameters
        int numberOfInputs:  the number of inputs
        int numberOfLayers: number of hidden layers
        list hiddenLayerNodes: the number of nodes in each hidden layer
        string activasion: the activasion function
        boolean classifier: the neural network is a classifier or not 
        float alpha: the learning rate 
        float tol: the tolerance for the target accuracy
        int max_epochs = maximum number of iterations; refering to epochs
        boolean verbose: print the iterations 
        int max_iter_stop: stop if the accuracy is not being improved for a number of iterations 
        '''
        self.numberOfInputs = numberOfInputs
      #  self.numberOfLayers = numberOfLayers
        self.hiddenLayerNodes = hiddenLayerNodes
        self.activation = activation
        self.activationFunction = self.act_functions[activation]
        self.derivative = self.derivatives[activation]
        self.classifier = classifier
        self.alpha = alpha 
        self.tol = tol
        self.max_iter_stop = max_iter_stop
        self.max_epochs = max_epochs
        self.verbose = verbose
        

        # The number of nodes for each layer including the input and the output. They are all kept in a list.
        self.allLayerNodes = [self.numberOfInputs]
        for i in self.hiddenLayerNodes: self.allLayerNodes.append(i)
        self.allLayerNodes.append(1)

        # We store the weights and the bias  in theese lists 
        self.weightMatrixes = []
        '''
             [[w11,w12,w13]
        W1 =   w21,w22,w23]
               w31,w32,w33]]   
         
        '''
        self.biasMatrixes = []  # they are going to be stored as arrays !!!! 


        # We store the wistory for the error in the list
        self.error_record = []
        print(self)

    
    
    def __str__(self):
        '''
        Information on a string

        '''
        return "numberOfInputs = " + str(self.numberOfInputs)+ " hidddenLayerNodes = " + str(self.hiddenLayerNodes) +" activation = " + self.activation+" classifier =" + str(self.classifier)+ " alpha ="  + str(self.alpha)+ " tol =" +str(self.tol)+ " max_epochs ="+ str(self.max_epochs)+ " verbose = " + str(self.verbose)+ " max_iter_stop = "+ str(self.max_iter_stop) 
        

    
    
    
    ## Fitting and prediction 
    def fit(self,X_training  ,y_training):
        '''
        Function that performs the training for the neural network according to the back propagation algorithm
        X_training: A 2D array with the samples in rows 
        y_training: An 1D array with the expected values

        '''
       

        self.error_record = []
        n, d = X_training.shape
        X_tr = X_training.transpose() ## Transpose the data for the training according to the format: samples in COLUMNS
        if n != y_training.size:
            raise Exception("Number of samples does not match the y-array size")

        if len(self.hiddenLayerNodes) == 2:
            ## Initiate the weights and the bias with random numbers
            self.W1 = np.random.rand(self.hiddenLayerNodes[0],self.numberOfInputs)
            self.b1 = np.random.rand(self.hiddenLayerNodes[0])
            self.W2 = np.random.rand(self.hiddenLayerNodes[1],self.hiddenLayerNodes[0])
            self.b2 = np.random.rand(self.hiddenLayerNodes[1])
            self.W3 = np.random.rand(self.hiddenLayerNodes[1])
            self.b3 = np.random.rand()      

            if not self.classifier:
                    

                iters = 0
                epochs = 0
                batchSize = min(100,n)
                index_list = list(range(n))
                notSuf = 0
                err = 1
                epFlag = False
                self.error_record = []
                ## Start the main loop for the training 
                while True:
                    '''
                    if len(index_list) < batchSize:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    else:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1                                
                '''
                    if len(index_list) // batchSize == 0:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    elif len(index_list) // batchSize > 0:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1   
                    X = X_tr[:,batch]     ## Batxh of X_training
                    y = y_training[batch]  ## Batxh of y_training
                

                    err1 = self.squaredLoss(X.T,y,total = True) ## X is transposed. We transpose it again for the squared loss and predict is going to transpose it again
                    #print("iter = ",iters , "err1 = ", err1 )
                    if epFlag:
                        self.error_record.append(err1)
                        if self.verbose:
                                print("Iteration: " + str(epochs) , "error: " + str(err1))
                        if abs(err - err1) < self.tol:
                            notSuf += 1
                            
                        else:
                            notSuf = 0  
                    err = err1
                    if (err < self.tol) or epochs > self.max_epochs: 
                        if err < self.tol:
                            print("Training stoped because tolerance has been achieved")
                        if epochs > self.max_epochs:
                            print("Training stopped because maximum number of epochs has been reached")
                        #if notSuf >self.max_iter_stop:
                            #print("Training stopped because error has not improved for " + str(self.max_iter_stop) + " epochs")
                        break




                    ## BACK PROPAGATION
                    ## We use the batches. The total error is the sum of all the errors
                    
                    loss =  self.squaredLoss(X.T,y,total = False) ## Array with the loss for each j- sample
                    delta2 = []
                    delta1 = []
                    delta3 = loss 

                    partial_weight1 = []
                    partial_bias1 = []
                    partial_weight2 = []
                    partial_bias2 = []
                    partial_weight3 = []
                    partial_bias3 = []
                    
                    deltaWeight1 = np.zeros(self.W1.shape)
                    deltaWeight2 = np.zeros(self.W2.shape)
                    deltaWeight3 = np.zeros(self.W3.shape)
                    deltaBias1 = np.zeros(self.b1.size)
                    deltaBias2 = np.zeros(self.b2.size)
                    deltaBias3 = 0.0
                    for j in range(y.size):
                        delta2.append((self.W3*delta3[j])*self.derivative(self.Z2[:,j])) # Derivative
                        delta1.append(np.dot(self.W2.transpose(),delta2[j])*self.derivative(self.Z1[:,j])) # Derivative
                        

                        partial_weight1.append(np.dot(np.expand_dims(delta1[j],1),np.expand_dims(X[:,j],1).transpose()))
                        partial_bias1.append(delta1[j])
                        partial_weight2.append(np.dot(np.expand_dims(delta2[j],1),np.expand_dims(self.A1[:,j],1).transpose()))
                        partial_bias2.append(delta2[j])
                        partial_weight3.append(delta3[j]*self.A2[:,j])
                        partial_bias3.append(delta3[j])
                
                    
                    for i in range(y.size):
                        deltaWeight1 += partial_weight1[i]
                        deltaBias1 += partial_bias1[i]
                        deltaWeight2 += partial_weight2[i]
                        deltaBias2 += partial_bias2[i]
                        
                        deltaWeight3 += partial_weight3[i]
                        deltaBias3 += partial_bias3[i]
                        
                    deltaWeight1 /= y.size
                    deltaWeight2 /= y.size
                    deltaWeight3 /= y.size
                    
                    deltaBias1 /= y.size
                    deltaBias2 /= y.size
                    deltaBias3 /= y.size

                    
                    self.W1-= self.alpha * deltaWeight1
                    self.W2-= self.alpha * deltaWeight2
                    self.W3-= self.alpha * deltaWeight3
                    self.b1 -= self.alpha * deltaBias1
                    self.b2 -= self.alpha * deltaBias2
                    self.b3 -= self.alpha * deltaBias3
                    
                


            else:
                iters = 0
                epochs = 0
                batchSize = min(100,n)
                index_list = list(range(n))
                notSuf = 0
                err = 1
                epFlag = False
                self.error_record = []
                ## Start the main loop for the training 
                while True:
                    '''
                    if len(index_list) < batchSize:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    else:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1                                
                '''
                    if len(index_list) // batchSize == 0:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    elif len(index_list) // batchSize > 0:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1   
                    X = X_tr[:,batch]     ## Batxh of X_training
                    y = y_training[batch]  ## Batxh of y_training
                

                    #err1 = self.squaredLoss(X.T,y,total = True) ## X is transposed. We transpose it again for the squared loss and predict is going to transpose it again
                    y_hat = self.predict(X.T, classificationTraining = True) # Predict takes a matrix non transposed
                    err1 = Utilities.entropyError(y,y_hat)

                    #print("iter = ",iters , "err1 = ", err1 )
                    if epFlag:
                        self.error_record.append(err1)
                        if self.verbose:
                                print("Iteration: " + str(epochs) , "error: " + str(err1))
                        if abs(err - err1) < self.tol:
                            notSuf += 1
                            
                        else:
                            notSuf = 0  
                    err = err1
                    if (err < self.tol) or epochs > self.max_epochs: 
                        if err < self.tol:
                            print("Training stoped because tolerance has been achieved")
                        if epochs > self.max_epochs:
                            print("Training stopped because maximum number of epochs has been reached")
                        #if notSuf >self.max_iter_stop:
                            #print("Training stopped because error has not improved for " + str(self.max_iter_stop) + " epochs")
                        break




                    ## BACK PROPAGATION
                    ## We use the batches. The total error is the sum of all the errors
                    
                    #loss =  self.squaredLoss(X.T,y,total = False) ## Array with the loss for each j- sample
                    loss = y/y_hat
                    delta2 = []
                    delta1 = []
                    delta3 = loss 

                    partial_weight1 = []
                    partial_bias1 = []
                    partial_weight2 = []
                    partial_bias2 = []
                    partial_weight3 = []
                    partial_bias3 = []
                    
                    deltaWeight1 = np.zeros(self.W1.shape)
                    deltaWeight2 = np.zeros(self.W2.shape)
                    deltaWeight3 = np.zeros(self.W3.shape)
                    deltaBias1 = np.zeros(self.b1.size)
                    deltaBias2 = np.zeros(self.b2.size)
                    deltaBias3 = 0.0

                    delta_J_delta_H = y/y_hat
                    h = np.dot(self.W3,self.A2) + self.b3
                    delta_H_delta_h = Utilities.logistic_derivative(h)

                    for j in range(y.size):
                        delta2.append((self.W3*delta3[j])*self.derivative(self.Z2[:,j])) # Derivative
                        delta1.append(np.dot(self.W2.transpose(),delta2[j])*self.derivative(self.Z1[:,j])) # Derivative
                        

                        partial_weight1.append(np.dot(np.expand_dims(delta1[j],1),np.expand_dims(X[:,j],1).transpose())*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_bias1.append(delta1[j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_weight2.append(np.dot(np.expand_dims(delta2[j],1),np.expand_dims(self.A1[:,j],1).transpose())*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_bias2.append(delta2[j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_weight3.append(delta3[j]*self.A2[:,j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_bias3.append(delta3[j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                
                    
                    for i in range(y.size):
                        deltaWeight1 -= partial_weight1[i]
                        deltaBias1 -= partial_bias1[i]
                        deltaWeight2 -= partial_weight2[i]
                        deltaBias2 -= partial_bias2[i]
                        
                        deltaWeight3 -= partial_weight3[i]
                        deltaBias3 -= partial_bias3[i]
                        
                    deltaWeight1 /= y.size
                    deltaWeight2 /= y.size
                    deltaWeight3 /= y.size
                    
                    deltaBias1 /= y.size
                    deltaBias2 /= y.size
                    deltaBias3 /= y.size

                    
                    self.W1-= self.alpha * deltaWeight1
                    self.W2-= self.alpha * deltaWeight2
                    self.W3-= self.alpha * deltaWeight3
                    self.b1 -= self.alpha * deltaBias1
                    self.b2 -= self.alpha * deltaBias2
                    self.b3 -= self.alpha * deltaBias3
                

        elif len(self.hiddenLayerNodes) == 1:
            ## Initiate the weights and the bias with random numbers
            self.W2 = np.random.rand(self.hiddenLayerNodes[0],self.numberOfInputs)
            self.b2 = np.random.rand(self.hiddenLayerNodes[0])
            #self.W2 = np.random.rand(self.hiddenLayerNodes[1],self.hiddenLayerNodes[0])
            #self.b2 = np.random.rand(self.hiddenLayerNodes[1])
            self.W3 = np.random.rand(self.hiddenLayerNodes[0])
            self.b3 = np.random.rand()      

            if not self.classifier:
                    

                iters = 0
                epochs = 0
                batchSize = min(100,n)
                index_list = list(range(n))
                notSuf = 0
                err = 1
                epFlag = False
                self.error_record = []
                ## Start the main loop for the training 
                while True:
                    '''
                    if len(index_list) < batchSize:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    else:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1                                
                '''
                    if len(index_list) // batchSize == 0:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    elif len(index_list) // batchSize > 0:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1   
                    X = X_tr[:,batch]     ## Batxh of X_training
                    y = y_training[batch]  ## Batxh of y_training
                

                    err1 = self.squaredLoss(X.T,y,total = True) ## X is transposed. We transpose it again for the squared loss and predict is going to transpose it again
                    #print("iter = ",iters , "err1 = ", err1 )
                    if epFlag:
                        self.error_record.append(err1)
                        if self.verbose:
                                print("Iteration: " + str(epochs) , "error: " + str(err1))
                        if abs(err - err1) < self.tol:
                            notSuf += 1
                            
                        else:
                            notSuf = 0  
                    err = err1
                    if (err < self.tol) or epochs > self.max_epochs: 
                        if err < self.tol:
                            print("Training stoped because tolerance has been achieved")
                        if epochs > self.max_epochs:
                            print("Training stopped because maximum number of epochs has been reached")
                        #if notSuf >self.max_iter_stop:
                            #print("Training stopped because error has not improved for " + str(self.max_iter_stop) + " epochs")
                        break




                    ## BACK PROPAGATION
                    ## We use the batches. The total error is the sum of all the errors
                    
                    loss =  self.squaredLoss(X.T,y,total = False) ## Array with the loss for each j- sample
                    delta2 = []
                   # delta1 = []
                    delta3 = loss 

                    #partial_weight1 = []
                    #partial_bias1 = []
                    partial_weight2 = []
                    partial_bias2 = []
                    partial_weight3 = []
                    partial_bias3 = []
                    
                   # deltaWeight1 = np.zeros(self.W1.shape)
                    deltaWeight2 = np.zeros(self.W2.shape)
                    deltaWeight3 = np.zeros(self.W3.shape)
                   # deltaBias1 = np.zeros(self.b1.size)
                    deltaBias2 = np.zeros(self.b2.size)
                    deltaBias3 = 0.0
                    for j in range(y.size):
                        delta2.append((self.W3*delta3[j])*self.derivative(self.Z2[:,j])) # derivative
                        #delta1.append(np.dot(self.W2.transpose(),delta2[j])*Utilities.logistic_derivative(self.Z1[:,j]))

                        #partial_weight1.append(np.dot(np.expand_dims(delta1[j],1),np.expand_dims(X[:,j],1).transpose()))
                        #partial_bias1.append(delta1[j])
                        partial_weight2.append(np.dot(np.expand_dims(delta2[j],1),np.expand_dims(X[:,j],1).transpose()))
                        partial_bias2.append(delta2[j])
                        partial_weight3.append(delta3[j]*self.A2[:,j])
                        partial_bias3.append(delta3[j])
                
                    
                    for i in range(y.size):
                      #  deltaWeight1 += partial_weight1[i]
                       # deltaBias1 += partial_bias1[i]
                        deltaWeight2 += partial_weight2[i]
                        deltaBias2 += partial_bias2[i]
                        
                        deltaWeight3 += partial_weight3[i]
                        deltaBias3 += partial_bias3[i]
                        
                   # deltaWeight1 /= y.size
                    deltaWeight2 /= y.size
                    deltaWeight3 /= y.size
                    
                   # deltaBias1 /= y.size
                    deltaBias2 /= y.size
                    deltaBias3 /= y.size

                    
                    #self.W1-= self.alpha * deltaWeight1
                    self.W2-= self.alpha * deltaWeight2
                    self.W3-= self.alpha * deltaWeight3
                    #self.b1 -= self.alpha * deltaBias1
                    self.b2 -= self.alpha * deltaBias2
                    self.b3 -= self.alpha * deltaBias3
            else:
                iters = 0
                epochs = 0
                batchSize = min(100,n)
                index_list = list(range(n))
                notSuf = 0
                err = 1
                epFlag = False
                self.error_record = []
                ## Start the main loop for the training 
                while True:
                    '''
                    if len(index_list) < batchSize:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    else:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1                                
                '''
                    if len(index_list) // batchSize == 0:
                        batch = index_list
                        index_list = list(range(n))
                        iters +=1
                        epochs += 1
                        epFlag = True
                    elif len(index_list) // batchSize > 0:
                        epFlag = False
                        batch = random.sample(index_list,batchSize)
                        index_list = [el for el in index_list if el not in batch]
                        iters += 1   
                    X = X_tr[:,batch]     ## Batxh of X_training
                    y = y_training[batch]  ## Batxh of y_training
                

                    #err1 = self.squaredLoss(X.T,y,total = True) ## X is transposed. We transpose it again for the squared loss and predict is going to transpose it again
                    y_hat = self.predict(X.T, classificationTraining = True) # Predict takes a matrix non transposed
                    err1 = Utilities.entropyError(y,y_hat)

                    #print("iter = ",iters , "err1 = ", err1 )
                    if epFlag:
                        self.error_record.append(err1)
                        if self.verbose:
                                print("Iteration: " + str(epochs) , "error: " + str(err1))
                        if abs(err - err1) < self.tol:
                            notSuf += 1
                            
                        else:
                            notSuf = 0  
                    err = err1
                    if (err < self.tol) or epochs > self.max_epochs: 
                        if err < self.tol:
                            print("Training stoped because tolerance has been achieved")
                        if epochs > self.max_epochs:
                            print("Training stopped because maximum number of epochs has been reached")
                        #if notSuf >self.max_iter_stop:
                            #print("Training stopped because error has not improved for " + str(self.max_iter_stop) + " epochs")
                        break




                    ## BACK PROPAGATION
                    ## We use the batches. The total error is the sum of all the errors
                    
                    #loss =  self.squaredLoss(X.T,y,total = False) ## Array with the loss for each j- sample
                    loss = y/y_hat
                    delta2 = []
                   # delta1 = []
                    delta3 = loss 

                    #partial_weight1 = []
                    #partial_bias1 = []
                    partial_weight2 = []
                    partial_bias2 = []
                    partial_weight3 = []
                    partial_bias3 = []
                    
                    #deltaWeight1 = np.zeros(self.W1.shape)
                    deltaWeight2 = np.zeros(self.W2.shape)
                    deltaWeight3 = np.zeros(self.W3.shape)
                    #deltaBias1 = np.zeros(self.b1.size)
                    deltaBias2 = np.zeros(self.b2.size)
                    deltaBias3 = 0.0

                    delta_J_delta_H = y/y_hat
                    h = np.dot(self.W3,self.A2) + self.b3
                    delta_H_delta_h = Utilities.logistic_derivative(h)

                    for j in range(y.size):
                        delta2.append((self.W3*delta3[j])*self.derivative(self.Z2[:,j])) # Derivative
                        #delta1.append(np.dot(self.W2.transpose(),delta2[j])*self.derivative(self.Z1[:,j])) # Derivative
                        

                        #partial_weight1.append(np.dot(np.expand_dims(delta1[j],1),np.expand_dims(X[:,j],1).transpose())*delta_J_delta_H[j]*delta_H_delta_h[j])
                        #partial_bias1.append(delta1[j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_weight2.append(np.dot(np.expand_dims(delta2[j],1),np.expand_dims(X[:,j],1).transpose())*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_bias2.append(delta2[j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_weight3.append(delta3[j]*self.A2[:,j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                        partial_bias3.append(delta3[j]*delta_J_delta_H[j]*delta_H_delta_h[j])
                
                    
                    for i in range(y.size):
                        #deltaWeight1 -= partial_weight1[i]
                        #deltaBias1 -= partial_bias1[i]
                        deltaWeight2 -= partial_weight2[i]
                        deltaBias2 -= partial_bias2[i]
                        
                        deltaWeight3 -= partial_weight3[i]
                        deltaBias3 -= partial_bias3[i]
                        
                    #deltaWeight1 /= y.size
                    deltaWeight2 /= y.size
                    deltaWeight3 /= y.size
                    
                    #deltaBias1 /= y.size
                    deltaBias2 /= y.size
                    deltaBias3 /= y.size

                    
                    #self.W1-= self.alpha * deltaWeight1
                    self.W2-= self.alpha * deltaWeight2
                    self.W3-= self.alpha * deltaWeight3
                    #self.b1 -= self.alpha * deltaBias1
                    self.b2 -= self.alpha * deltaBias2
                    self.b3 -= self.alpha * deltaBias3









    def predict(self,x,classificationTraining = False):

        '''
        The feed - forward function
        x: An 1D array with the inputs 
        '''
        N = x.shape[0]
        if not self.classifier:
            #N = x.shape[0]
            if x.shape[0] == 1:
                y = x[0,:]

                if y.size != self.numberOfInputs:
                    raise Exception("Nummber of inputs does not match the number of inputs in the trained model")
                for i in range(self.numberOfLayers):
                    z = self.weightMatrixes[i].dot(y) + self.biasMatrixes[i]
                    a = self.activationFunction(z)
                    y = a 
                ar = self.weightMatrixes[-1].dot(y) + self.biasMatrixes[-1]    
                if not self.classifier:
                    return ar 
                else: 
                    return softmax(ar)

            elif x.shape[1] > 1:   ##  x is NOT in the training format
                ## We are having two hidden layers
                X = x.transpose()           
            

                '''
                self.W1 = np.random.rand(self.hiddenLayerNodes[0],self.numberOfInputs)
                self.b1 = np.random.rand(self.hiddenLayerNodes[0])
                self.W2 = np.random.rand(self.hiddenLayerNodes[1],self.hiddenLayerNodes[0])
                self.b2 = np.random.rand(self.hiddenLayerNodes[1])
                self.W3 = np.random.rand(self.hiddenLayerNodes[1])
                self.b3 = np.random.rand()
            '''
                if len(self.hiddenLayerNodes) == 1:
                    #self.Z1 = np.dot(self.W1, X ) + np.array([self.b1 for k in range(N)]).transpose()
                    #self.A1 = Utilities.logistic(self.Z1)

                    self.Z2 = np.dot(self.W2,X) + np.array([self.b2 for k in range(N)]).transpose()
                    self.A2 = self.activationFunction(self.Z2)

                    out = np.dot(self.W3,self.A2) + self.b3  ## W3 and b3 are both arrays
                    return out ## an array
                elif len(self.hiddenLayerNodes) == 2:
                    self.Z1 = np.dot(self.W1, X ) + np.array([self.b1 for k in range(N)]).transpose()
                    self.A1 = self.activationFunction(self.Z1)

                    self.Z2 = np.dot(self.W2,self.A1) + np.array([self.b2 for k in range(N)]).transpose()
                    self.A2 = self.activationFunction(self.Z2)

                    out = np.dot(self.W3,self.A2) + self.b3  ## W3 and b3 are both arrays
                    return out ## an array

        else:
            X = x.transpose()  # Bring it to the training format 
            if len(self.hiddenLayerNodes) == 1:
                #self.Z1 = np.dot(self.W1, X ) + np.array([self.b1 for k in range(N)]).transpose()
                #self.A1 = Utilities.logistic(self.Z1)

                self.Z2 = np.dot(self.W2,X) + np.array([self.b2 for k in range(N)]).transpose()
                self.A2 = self.activationFunction(self.Z2)

                out = np.dot(self.W3,self.A2) + self.b3  ## W3 and b3 are both arrays

                return Utilities.logistic(out,discrete = False) if classificationTraining else Utilities.logistic(out,discrete = True) ## an array
            elif len(self.hiddenLayerNodes) == 2:
                self.Z1 = np.dot(self.W1, X ) + np.array([self.b1 for k in range(N)]).transpose()
                self.A1 = self.activationFunction(self.Z1)

                self.Z2 = np.dot(self.W2,self.A1) + np.array([self.b2 for k in range(N)]).transpose()
                self.A2 = self.activationFunction(self.Z2)

                out = np.dot(self.W3,self.A2) + self.b3  ## W3 and b3 are both arrays
                return Utilities.logistic(out,discrete = False) if classificationTraining else Utilities.logistic(out,discrete = True) ## an array




    ## Getters 
    def getErrorRecord(self):
        return np.array(self.error_record)
    
    def weights_(self):
        return self.W1, self.W2, self.W3 if ( not self.W1 is None) else self.W2, self.W3 
    
    def bias_(self):
        return self.b1, self.b2 , self.b3 if ( not self.b1 is None) else self.b2, self.b3
         




#########################################   

