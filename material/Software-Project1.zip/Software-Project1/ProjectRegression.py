#Παναγιώτης Δούλης, 1822
#Ευάγγελος Τσιάμαλος, 2604

import numpy as np


class AutoRegression:
    '''
    Class that descrices the Regression Model
    '''
    
    def __init__(self):
        '''
        Constructor
        '''
        self.theta = None
        self.J = None
    
    def fit(self,x,y):
        '''
        Training method with canonical equations
        x is not to have units in the first column
        '''
        n_targets = len(y)
        x = np.hstack((np.ones((n_targets, 1)), x))
        
        
        x_traing_trans = np.transpose(x)

        X = x_traing_trans.dot(x)

        X_inv = np.linalg.inv(X)

        X_y = x_traing_trans.dot(y)

        self.theta = X_inv.dot(X_y)
        
        return self.theta
        
        
    
    
    
    def predict(self,x):
        '''
        Prediction of model
        x is not to have units in the first column 
        '''
        l = x.shape[0]
        x = np.hstack((np.ones((l, 1)), x))
        
        y_pred = x.dot(self.theta)
        
        return y_pred 
    
    def thetas_(self):
        
        return self.theta
    
    
    def loss(self,x, y):
        '''
        Loss function
        '''
        m = x.shape[0]
        x = np.hstack((np.ones((m, 1)), x))
        prediction = x.dot(self.theta)
        error = np.subtract(prediction, y)
        sqerror = np.square(error)
        self.J = 1 / (2*(m)) * np.sum(sqerror)
        return self.J
        
    
    
    def loss_(self):
        
        return self.J
        
    
    def score_2(self,x,y):
        
        score = 1 - (((x - y) ** 2).sum())/(((x - x.mean()) ** 2).sum())
        return score
        
    